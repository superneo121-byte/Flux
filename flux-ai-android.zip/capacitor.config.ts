import type { CapacitorConfig } from '@capacitor/cli';

const config = {
  appId: 'com.darkflux.ai',
  appName: 'Flux AI',
  webDir: 'dist',
  backgroundColor: '#0e0f14',
  server: { androidScheme: 'https' },
  android: {
    backgroundColor: '#0e0f14',
    // Keeps the WebView content clear of the status/navigation bars on Android 15+ (edge-to-edge)
    adjustMarginsForEdgeToEdge: 'auto',
  },
} as CapacitorConfig;

export default config;
