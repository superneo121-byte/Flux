import { useState, useEffect, useRef } from "react";
import { apiFetch } from "./lib/apiClient";
import { saveTextFile } from "./lib/native";
import { Capacitor } from "@capacitor/core";
import { App as CapacitorApp } from "@capacitor/app";
import { FluxHeader } from "./components/FluxHeader";
import { FluxSidebar } from "./components/FluxSidebar";
import { FluxWelcomeState } from "./components/FluxWelcomeState";
import { FluxChatInput } from "./components/FluxChatInput";
import { OutputArena } from "./components/OutputArena";
import { DiffViewerModal } from "./components/DiffViewerModal";
import { KeySettingsModal } from "./components/KeySettingsModal";
import { SettingsModal, THEME_PRESETS } from "./components/SettingsModal";
import { ExpandModal } from "./components/ExpandModal";
import { ShortcutsModal } from "./components/ShortcutsModal";
import { SYSTEM_PRESETS } from "./constants/presets";
import { AVAILABLE_MODELS } from "./constants/models";
import { BYOKSettings, ModelRunResult, SessionHistoryItem } from "./types";

export default function App() {
  // Theme State
  const [themeMode, setThemeMode] = useState<"light" | "dark" | "system">("dark");
  const [themeId, setThemeId] = useState<string>(() => {
    try {
      return localStorage.getItem("dark_flux_theme") || "obsidian";
    } catch (e) {
      return "obsidian";
    }
  });

  // Apply theme class to document element
  useEffect(() => {
    if (themeMode === "dark") {
      document.documentElement.classList.add("dark");
    } else if (themeMode === "light") {
      document.documentElement.classList.remove("dark");
    } else {
      if (window.matchMedia("(prefers-color-scheme: dark)").matches) {
        document.documentElement.classList.add("dark");
      } else {
        document.documentElement.classList.remove("dark");
      }
    }
  }, [themeMode]);

  // BYOK Local Storage State
  const [byok, setByok] = useState<BYOKSettings>(() => {
    try {
      const saved = localStorage.getItem("dark_flux_byok");
      return saved ? JSON.parse(saved) : {};
    } catch (e) {
      return {};
    }
  });

  // Hyperparameters
  const [systemPrompt, setSystemPrompt] = useState<string>(SYSTEM_PRESETS[0].systemPrompt);
  const [selectedPresetId, setSelectedPresetId] = useState<string>("default");
  const [temperature, setTemperature] = useState<number>(0.7);
  const [topP, setTopP] = useState<number>(0.95);
  const [maxTokens, setMaxTokens] = useState<number>(2048);

  // Input & Studio State
  const [prompt, setPrompt] = useState<string>("");
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const [enableSearch, setEnableSearch] = useState<boolean>(false);
  const [selectedModelIds, setSelectedModelIds] = useState<string[]>([
    "gemini-3.6-flash",
    "claude-3-5-sonnet",
    "deepseek-r1",
  ]);

  // Execution & Output Arena State
  const [results, setResults] = useState<Record<string, ModelRunResult>>({});
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [isEnhancing, setIsEnhancing] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<"grid" | "diff">("grid");

  // History State
  const [history, setHistory] = useState<SessionHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem("dark_flux_history");
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  // UI Modals & Sidebar
  const [isBYOKModalOpen, setIsBYOKModalOpen] = useState<boolean>(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState<boolean>(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState<boolean>(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(() => typeof window !== "undefined" && window.matchMedia("(min-width: 768px)").matches);
  const [expandedResult, setExpandedResult] = useState<ModelRunResult | null>(null);

  // Abort controller reference for cancelling streams
  const abortControllersRef = useRef<Record<string, AbortController>>({});

  // Save BYOK to Local Storage
  const handleSaveKeys = (newKeys: BYOKSettings) => {
    setByok(newKeys);
    localStorage.setItem("dark_flux_byok", JSON.stringify(newKeys));
  };

  // Save Theme to Local Storage
  useEffect(() => {
    try {
      localStorage.setItem("dark_flux_theme", themeId);
    } catch (e) {}
  }, [themeId]);

  // Save History to Local Storage
  useEffect(() => {
    try {
      localStorage.setItem("dark_flux_history", JSON.stringify(history.slice(0, 30)));
    } catch (e) {
      console.error("Failed to save history:", e);
    }
  }, [history]);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setIsBYOKModalOpen(false);
        setIsSettingsModalOpen(false);
        setIsShortcutsOpen(false);
        setExpandedResult(null);
      } else if (e.altKey && (e.key === "s" || e.key === "S")) {
        e.preventDefault();
        setIsSettingsModalOpen((prev) => !prev);
      } else if (e.altKey && (e.key === "b" || e.key === "B")) {
        e.preventDefault();
        setIsBYOKModalOpen((prev) => !prev);
      } else if (e.altKey && (e.key === "c" || e.key === "C")) {
        e.preventDefault();
        handleClearSession();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  // Android hardware/gesture Back: close the top-most overlay first, otherwise minimize the app
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;
    const sub = CapacitorApp.addListener("backButton", () => {
      if (expandedResult) setExpandedResult(null);
      else if (isSettingsModalOpen) setIsSettingsModalOpen(false);
      else if (isBYOKModalOpen) setIsBYOKModalOpen(false);
      else if (isShortcutsOpen) setIsShortcutsOpen(false);
      else if (isSidebarOpen && window.innerWidth < 768) setIsSidebarOpen(false);
      else CapacitorApp.minimizeApp();
    });
    return () => {
      sub.then((h) => h.remove());
    };
  }, [expandedResult, isSettingsModalOpen, isBYOKModalOpen, isShortcutsOpen, isSidebarOpen]);

  const currentTheme = THEME_PRESETS.find((t) => t.id === themeId) || THEME_PRESETS[0];

  // Enhance Prompt Action
  const handleEnhancePrompt = async () => {
    if (!prompt.trim() || isEnhancing) return;
    setIsEnhancing(true);
    try {
      const res = await apiFetch("/api/enhance-prompt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, byok }),
      });
      const data = await res.json();
      if (data.enhancedPrompt) {
        setPrompt(data.enhancedPrompt);
      }
    } catch (err) {
      console.error("Failed to enhance prompt:", err);
    } finally {
      setIsEnhancing(false);
    }
  };

  // Halt all ongoing generations
  const handleStopFlux = () => {
    Object.values(abortControllersRef.current).forEach((controller) => {
      controller.abort();
    });
    abortControllersRef.current = {};
    setIsRunning(false);
    setResults((prev) => {
      const updated = { ...prev };
      Object.keys(updated).forEach((id) => {
        if (updated[id].status === "streaming") {
          updated[id] = {
            ...updated[id],
            status: "completed",
            text: updated[id].text + "\n\n*[Generation halted by user]*",
          };
        }
      });
      return updated;
    });
  };

  // Execute Parallel Multi-Model Run ("Run Flux")
  const handleRunFlux = async () => {
    if (!prompt.trim() || selectedModelIds.length === 0 || isRunning) return;
    setIsRunning(true);
    const initialResults: Record<string, ModelRunResult> = {};
    selectedModelIds.forEach((id) => {
      const spec = AVAILABLE_MODELS.find((m) => m.id === id);
      initialResults[id] = {
        modelId: id,
        modelName: spec?.name || id,
        provider: spec?.provider || "AI",
        status: enableSearch ? "grounding" : "streaming",
        text: "",
        reasoning: "",
        startTime: Date.now(),
      };
    });
    setResults(initialResults);
    abortControllersRef.current = {};

    // Execute fetches in parallel across all selected models
    const executionPromises = selectedModelIds.map(async (modelId) => {
      const controller = new AbortController();
      abortControllersRef.current[modelId] = controller;
      try {
        const response = await apiFetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({
            modelId,
            prompt,
            systemPrompt,
            temperature,
            topP,
            maxTokens,
            byok,
            image: attachedImage,
            enableSearch,
          }),
        });

        if (!response.ok || !response.body) {
          throw new Error(`HTTP Error ${response.status}`);
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";
          for (const line of lines) {
            const trimmed = line.trim();
            if (trimmed.startsWith("data: ")) {
              const dataStr = trimmed.substring(6);
              try {
                const parsed = JSON.parse(dataStr);
                if (parsed.error) {
                  setResults((prev) => ({
                    ...prev,
                    [modelId]: {
                      ...prev[modelId],
                      status: "error",
                      error: parsed.error,
                    },
                  }));
                  break;
                }

                setResults((prev) => {
                  const current = prev[modelId] || {
                    modelId,
                    modelName: modelId,
                    provider: "AI",
                    status: "streaming",
                    text: "",
                  };
                  const updatedText = current.text + (parsed.chunk || "");
                  const updatedReasoning = (current.reasoning || "") + (parsed.reasoning || "");
                  const updatedSources = parsed.sources || current.sources;
                  return {
                    ...prev,
                    [modelId]: {
                      ...current,
                      text: updatedText,
                      reasoning: updatedReasoning,
                      sources: updatedSources,
                      status: parsed.isGrounding
                        ? "grounding"
                        : parsed.done
                        ? "completed"
                        : "streaming",
                      latencyMs: parsed.latencyMs || current.latencyMs,
                      tokensPerSec: parsed.tokensPerSec || current.tokensPerSec,
                    },
                  };
                });
              } catch (e) {
                // Ignore parse errors on partial chunks
              }
            }
          }
        }
      } catch (err: any) {
        if (err.name === "AbortError") return;
        setResults((prev) => ({
          ...prev,
          [modelId]: {
            ...prev[modelId],
            status: "error",
            error: err.message || "Failed to communicate with model runner.",
          },
        }));
      }
    });

    await Promise.allSettled(executionPromises);
    setIsRunning(false);

    // Save session to history with final results
    setResults((finalResults) => {
      const historyItem: SessionHistoryItem = {
        id: Date.now().toString(),
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        prompt,
        systemPrompt,
        selectedModelIds,
        results: finalResults,
      };
      setHistory((prev) => [historyItem, ...prev]);
      return finalResults;
    });
  };

  // Single Model Regeneration
  const handleRegenerateModel = async (modelId: string) => {
    if (!prompt.trim() || isRunning) return;
    setResults((prev) => ({
      ...prev,
      [modelId]: {
        modelId,
        modelName: AVAILABLE_MODELS.find((m) => m.id === modelId)?.name || modelId,
        provider: AVAILABLE_MODELS.find((m) => m.id === modelId)?.provider || "AI",
        status: enableSearch ? "grounding" : "streaming",
        text: "",
        reasoning: "",
      },
    }));

    const controller = new AbortController();
    abortControllersRef.current[modelId] = controller;

    try {
      const response = await apiFetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
          modelId,
          prompt,
          systemPrompt,
          temperature,
          topP,
          maxTokens,
          byok,
          image: attachedImage,
          enableSearch,
        }),
      });

      if (!response.ok || !response.body) throw new Error("HTTP error");

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
        for (const line of lines) {
          const trimmed = line.trim();
          if (trimmed.startsWith("data: ")) {
            const dataStr = trimmed.substring(6);
            try {
              const parsed = JSON.parse(dataStr);
              setResults((prev) => {
                const spec = AVAILABLE_MODELS.find((m) => m.id === modelId);
                const current: ModelRunResult = prev[modelId] || {
                  modelId,
                  modelName: spec?.name || modelId,
                  provider: spec?.provider || "AI",
                  status: "streaming",
                  text: "",
                };
                return {
                  ...prev,
                  [modelId]: {
                    ...current,
                    text: current.text + (parsed.chunk || ""),
                    reasoning: (current.reasoning || "") + (parsed.reasoning || ""),
                    sources: parsed.sources || current.sources,
                    status: parsed.isGrounding
                      ? "grounding"
                      : parsed.done
                      ? ("completed" as const)
                      : ("streaming" as const),
                    latencyMs: parsed.latencyMs || current.latencyMs,
                    tokensPerSec: parsed.tokensPerSec || current.tokensPerSec,
                  },
                };
              });
            } catch (e) {}
          }
        }
      }
    } catch (err: any) {
      setResults((prev) => ({
        ...prev,
        [modelId]: {
          ...prev[modelId],
          status: "error",
          error: err.message || "Regeneration failed.",
        },
      }));
    }
  };

  // Clear workspace
  const handleClearSession = () => {
    setResults({});
    setPrompt("");
    setAttachedImage(null);
  };

  // Export session transcript
  const handleExportSession = () => {
    const exportData = {
      app: "Flux AI",
      exportedAt: new Date().toISOString(),
      prompt,
      systemPrompt,
      hyperparameters: { temperature, topP, maxTokens },
      selectedModels: selectedModelIds,
      outputs: results,
    };
    saveTextFile(`flux_ai_session_${Date.now()}.json`, JSON.stringify(exportData, null, 2), "application/json");
  };

  // Load Past History Item
  const handleLoadHistoryItem = (item: SessionHistoryItem) => {
    setPrompt(item.prompt);
    setSystemPrompt(item.systemPrompt);
    setSelectedModelIds(item.selectedModelIds);
    if (item.results && Object.keys(item.results).length > 0) {
      setResults(item.results as Record<string, ModelRunResult>);
    }
  };

  // Delete History Item
  const handleDeleteHistoryItem = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setHistory((prev) => prev.filter((item) => item.id !== id));
  };

  // New Chat action
  const handleNewChat = () => {
    setResults({});
    setPrompt("");
    setAttachedImage(null);
  };

  const hasActiveOutputs = Object.keys(results).length > 0;

  return (
    <div
      className={`h-[100dvh] overflow-hidden flex flex-col font-sans select-text transition-colors duration-300 ${
        themeMode === "light" ? "text-zinc-900 bg-[#f7f9fb]" : "text-zinc-100"
      }`}
      style={{
        backgroundColor: themeMode === "light" ? "#f7f9fb" : currentTheme.bgHex,
      }}
    >
      {/* Flux Top Header */}
      <FluxHeader
        isSidebarOpen={isSidebarOpen}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        themeMode={themeMode}
        setThemeMode={setThemeMode}
        onOpenSettingsModal={() => setIsSettingsModalOpen(true)}
        byok={byok}
        onClearSession={handleClearSession}
        onExportSession={handleExportSession}
        activeSessionHistory={history}
        onShowShortcuts={() => setIsShortcutsOpen(true)}
        viewMode={viewMode}
        setViewMode={setViewMode}
        hasResults={hasActiveOutputs}
      />

      {/* Main Container Layout */}
      <div className="flex flex-1 min-h-0 overflow-hidden relative">
        {/* Navigation Sidebar */}
        <FluxSidebar
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
          onNewChat={handleNewChat}
          history={history}
          onLoadHistoryItem={handleLoadHistoryItem}
          onDeleteHistoryItem={handleDeleteHistoryItem}
          onOpenSettings={() => setIsSettingsModalOpen(true)}
        />

        {/* Main Chat Workspace */}
        <main className="flex-1 min-w-0 flex flex-col overflow-hidden relative">
          <div className="flex-1 overflow-y-auto overscroll-contain custom-scrollbar p-3 sm:p-4 flex flex-col">
            {!hasActiveOutputs ? (
              <FluxWelcomeState
                onSelectPrompt={(pText) => {
                  setPrompt(pText);
                }}
              />
            ) : (
              <div className="max-w-6xl mx-auto w-full pb-8">
                {/* User Prompt Display Badge */}
                <div className="mb-4 p-4 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-500/30 text-zinc-900 dark:text-zinc-100 text-sm font-sans flex items-start gap-3 shadow-xs">
                  <div className="p-1.5 rounded-lg bg-indigo-600 text-white shrink-0 mt-0.5">
                    <span className="font-bold text-xs font-mono">YOU</span>
                  </div>
                  <p className="leading-relaxed whitespace-pre-wrap">{prompt}</p>
                </div>

                {/* Model Results Arena */}
                {viewMode === "grid" ? (
                  <OutputArena
                    results={results}
                    selectedModelIds={selectedModelIds}
                    onRegenerateModel={handleRegenerateModel}
                    onOpenExpandModal={(res) => setExpandedResult(res)}
                  />
                ) : (
                  <DiffViewerModal results={results} selectedModelIds={selectedModelIds} />
                )}
              </div>
            )}
          </div>

          {/* Bottom Chat Input Bar */}
          <div className="shrink-0 relative z-20 bg-gradient-to-t from-[#f7f9fb] via-[#f7f9fb]/95 to-transparent dark:from-[#09090b] dark:via-[#09090b]/90 dark:to-transparent pt-2 pb-[env(safe-area-inset-bottom)]">
            <FluxChatInput
              prompt={prompt}
              setPrompt={setPrompt}
              onRunFlux={handleRunFlux}
              onStopFlux={handleStopFlux}
              isRunning={isRunning}
              onEnhancePrompt={handleEnhancePrompt}
              isEnhancing={isEnhancing}
              attachedImage={attachedImage}
              setAttachedImage={setAttachedImage}
              enableSearch={enableSearch}
              setEnableSearch={setEnableSearch}
              selectedModelIds={selectedModelIds}
              setSelectedModelIds={setSelectedModelIds}
              onOpenSettings={() => setIsSettingsModalOpen(true)}
            />
          </div>
        </main>
      </div>

      {/* Modals */}
      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        byok={byok}
        onSaveKeys={handleSaveKeys}
        currentThemeId={themeId}
        setThemeId={setThemeId}
        temperature={temperature}
        setTemperature={setTemperature}
        topP={topP}
        setTopP={setTopP}
        maxTokens={maxTokens}
        setMaxTokens={setMaxTokens}
        systemPrompt={systemPrompt}
        setSystemPrompt={setSystemPrompt}
        selectedPresetId={selectedPresetId}
        setSelectedPresetId={setSelectedPresetId}
        onClearSession={handleClearSession}
        onExportSession={handleExportSession}
      />
      <KeySettingsModal
        isOpen={isBYOKModalOpen}
        onClose={() => setIsBYOKModalOpen(false)}
        byok={byok}
        onSaveKeys={handleSaveKeys}
      />
      <ShortcutsModal isOpen={isShortcutsOpen} onClose={() => setIsShortcutsOpen(false)} />
      <ExpandModal result={expandedResult} onClose={() => setExpandedResult(null)} />
    </div>
  );
}
