export interface BYOKSettings {
  geminiApiKey?: string;
  openRouterApiKey?: string;
  groqApiKey?: string;
  searchApiKey?: string;
}

export interface WebSource {
  title: string;
  url: string;
  snippet?: string;
  domain?: string;
}

export interface ModelSpec {
  id: string;
  name: string;
  provider: "Google" | "Anthropic" | "OpenAI" | "Meta" | "DeepSeek" | "Mistral";
  providerLogo?: string;
  description: string;
  contextWindow: string;
  badge: "Fast" | "Pro" | "Reasoning" | "Vision" | "Open Source";
  tagColor: string; // Tailwind color class for border/glow
  defaultSelected?: boolean;
  estLatencyMs: number;
  estTokensPerSec: number;
  costPer1k: string;
}

export interface ModelRunResult {
  modelId: string;
  modelName: string;
  provider: string;
  status: "idle" | "grounding" | "streaming" | "completed" | "error";
  text: string;
  reasoning?: string;
  sources?: WebSource[];
  error?: string;
  latencyMs?: number;
  tokensPerSec?: number;
  tokenCount?: number;
  startTime?: number;
  liked?: boolean | null;
}

export interface SystemPreset {
  id: string;
  name: string;
  description: string;
  iconName: string;
  systemPrompt: string;
}

export interface PromptTemplate {
  id: string;
  title: string;
  category: "Code" | "Analysis" | "Creative" | "Refine" | "Debug";
  prompt: string;
  systemPromptPresetId?: string;
}

export interface SessionHistoryItem {
  id: string;
  timestamp: string;
  prompt: string;
  systemPrompt: string;
  selectedModelIds: string[];
  results: Record<string, Partial<ModelRunResult>>;
}
