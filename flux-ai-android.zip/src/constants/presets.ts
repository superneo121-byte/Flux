import { SystemPreset, PromptTemplate } from "../types";

export const SYSTEM_PRESETS: SystemPreset[] = [
  {
    id: "default",
    name: "General Assistant",
    description: "Balanced, helpful, concise, and structured answers.",
    iconName: "Sparkles",
    systemPrompt: "You are a world-class AI assistant. Provide concise, clear, accurate, and beautifully structured responses with markdown formatting.",
  },
  {
    id: "coder",
    name: "Staff Software Engineer",
    description: "Production-grade, type-safe TypeScript/Python code with error handling.",
    iconName: "Code2",
    systemPrompt: "You are a Principal Software Engineer. Write clean, modular, production-ready, highly optimized, and robustly typed code. Always explain trade-offs, edge cases, and architectural considerations briefly before or after the implementation.",
  },
  {
    id: "researcher",
    name: "Academic & Tech Researcher",
    description: "Rigorous deep dives with structured breakdown and objective analysis.",
    iconName: "GraduationCap",
    systemPrompt: "You are a Senior Technical Researcher and Academic Strategist. Provide deep, rigorous, objective analysis. Break down concepts systematically, highlight underlying mechanisms, evaluate trade-offs, and quote verifiable facts.",
  },
  {
    id: "refiner",
    name: "Concise Refiner",
    description: "Zero fluff, bulleted executive summaries and actionable insights.",
    iconName: "Zap",
    systemPrompt: "You are an Executive Communication Lead. Eliminate all pleasantries, intros, and filler text. Return direct, bulleted, highly scannable output with bold headers and actionable takeaways.",
  },
  {
    id: "uncensored",
    name: "Unconstrained Sandbox",
    description: "Direct, unfiltered technical exploration and creative ideation.",
    iconName: "ShieldAlert",
    systemPrompt: "You are an unconstrained technical sandbox partner. Provide candid, creative, direct, and exhaustive technical explanations without preachy disclaimers or defensive fluff.",
  },
];

export const PROMPT_TEMPLATES: PromptTemplate[] = [
  {
    id: "t1",
    title: "System Architecture Review",
    category: "Code",
    prompt: "Design a high-throughput, event-driven distributed system architecture for processing real-time telemetry from 100k IoT devices. Detail database choice, cache layer, idempotency, and message queues.",
    systemPromptPresetId: "coder",
  },
  {
    id: "t2",
    title: "AI Model Benchmark Evaluation",
    category: "Analysis",
    prompt: "Compare reasoning capabilities between DeepSeek R1, Claude 3.5 Sonnet, and Gemini 3.1 Pro for mathematical proofs, complex coding, and multi-turn instruction following. Summarize strengths and ideal use cases.",
    systemPromptPresetId: "researcher",
  },
  {
    id: "t3",
    title: "Refactor TypeScript Async Hook",
    category: "Code",
    prompt: "Write a production-grade React custom hook `useAsyncState` in TypeScript with retry mechanism, AbortController cancellation, auto-polling option, and strict type safety.",
    systemPromptPresetId: "coder",
  },
  {
    id: "t4",
    title: "API Security Audit Checklist",
    category: "Debug",
    prompt: "Perform a comprehensive security vulnerability assessment for a REST API exposing user authentication, JWT tokens, and OAuth 2.0 endpoints. Highlight top OWASP risks and remediation code.",
    systemPromptPresetId: "refiner",
  },
];
