import { Capacitor } from "@capacitor/core";
import { Filesystem, Directory, Encoding } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";

export const isNative = () => Capacitor.isNativePlatform();

/** Saves/shares a text file. Android WebView ignores <a download>, so use the native share sheet there. */
export async function saveTextFile(filename: string, text: string, mime = "text/markdown;charset=utf-8") {
  const safeName = filename.replace(/[^\w.\-]+/g, "_");
  if (isNative()) {
    try {
      const res = await Filesystem.writeFile({
        path: safeName,
        data: text,
        directory: Directory.Cache,
        encoding: Encoding.UTF8,
      });
      await Share.share({ title: safeName, url: res.uri, dialogTitle: "Save or share file" });
    } catch (e: any) {
      // User dismissing the share sheet throws; ignore that case.
      if (!/cancel/i.test(String(e?.message || e))) console.error("Save failed:", e);
    }
    return;
  }
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = safeName;
  link.click();
  URL.revokeObjectURL(url);
}

export async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    return;
  } catch {}
  const ta = document.createElement("textarea");
  ta.value = text;
  ta.style.position = "fixed";
  ta.style.opacity = "0";
  document.body.appendChild(ta);
  ta.select();
  try {
    document.execCommand("copy");
  } catch {}
  document.body.removeChild(ta);
}
