import { CapacitorHttp } from "@capacitor/core";

/**
 * Client-side replacement for the old Express backend (server.ts / src/server/api.ts).
 * Exposes apiFetch(), which behaves like fetch() for "/api/chat" (SSE stream)
 * and "/api/enhance-prompt" (JSON), so the UI code stays unchanged.
 */

const GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta";
// Optional build-time key (VITE_GEMINI_API_KEY). Anything baked into an APK can be extracted,
// so prefer letting users enter their own key in BYOK settings.
const ENV_GEMINI_KEY: string = (import.meta as any).env?.VITE_GEMINI_API_KEY || "";

type SearchResult = { title: string; url: string; snippet: string; domain: string };

function geminiKey(byok: any): string {
  return byok?.geminiApiKey || ENV_GEMINI_KEY || "";
}

function geminiModelFor(modelId: string): string {
  if (modelId === "gemini-3.1-pro" || modelId === "gemini-pro") return "gemini-3.1-pro-preview";
  if (modelId === "gemini-3.1-flash-lite") return "gemini-3.1-flash-lite";
  return "gemini-3.6-flash";
}

function buildParts(prompt: string, image: string | null) {
  const parts: any[] = [];
  if (image) {
    const mime = image.match(/^data:([^;]+);base64,/)?.[1] || "image/png";
    parts.push({ inlineData: { mimeType: mime, data: image.split(",")[1] || image } });
  }
  parts.push({ text: prompt });
  return parts;
}

/** Reads an SSE response and calls onData with each "data: ..." payload. */
async function readSSE(resp: Response, onData: (payload: string) => void) {
  const reader = resp.body?.getReader();
  if (!reader) return;
  const decoder = new TextDecoder();
  let buffer = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() || "";
    for (const line of lines) {
      const t = line.trim();
      if (t.startsWith("data:")) onData(t.slice(5).trim());
    }
  }
}

// ---------- Web search (native HTTP bypasses CORS inside the Android app) ----------
async function performWebSearch(query: string, searchApiKey?: string): Promise<SearchResult[]> {
  if (searchApiKey && (searchApiKey.startsWith("tvly-") || searchApiKey.length > 15)) {
    try {
      const res = await CapacitorHttp.post({
        url: "https://api.tavily.com/search",
        headers: { "Content-Type": "application/json" },
        data: { api_key: searchApiKey, query, max_results: 5, search_depth: "basic" },
      });
      const data = typeof res.data === "string" ? JSON.parse(res.data) : res.data;
      if (res.status === 200 && data?.results?.length) {
        return data.results.map((item: any) => ({
          title: item.title,
          url: item.url,
          snippet: item.content || item.snippet || "",
          domain: new URL(item.url).hostname.replace("www.", ""),
        }));
      }
    } catch (e) {
      console.error("Tavily search error:", e);
    }
  }

  try {
    const res = await CapacitorHttp.get({
      url: `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`,
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
      },
    });
    if (res.status === 200 && typeof res.data === "string") {
      const html: string = res.data;
      const titleRe = /<a class="result__a" href="[^"]+">([\s\S]*?)<\/a>/g;
      const snippetRe = /<a class="result__snippet[^"]*">([\s\S]*?)<\/a>/g;
      const urlRe = /uddg=([^&"]+)/g;
      const strip = (s: string) => s.replace(/<[^>]+>/g, "").trim();
      const titles: string[] = [];
      const snippets: string[] = [];
      const urls: string[] = [];
      let m: RegExpExecArray | null;
      while ((m = titleRe.exec(html)) !== null && titles.length < 5) {
        const c = strip(m[1]);
        if (c) titles.push(c);
      }
      while ((m = snippetRe.exec(html)) !== null && snippets.length < 5) {
        const c = strip(m[1]);
        if (c) snippets.push(c);
      }
      while ((m = urlRe.exec(html)) !== null && urls.length < titles.length) {
        try {
          urls.push(decodeURIComponent(m[1]));
        } catch {}
      }
      const results: SearchResult[] = [];
      for (let i = 0; i < Math.min(titles.length, urls.length, 5); i++) {
        try {
          results.push({
            title: titles[i],
            url: urls[i],
            snippet: snippets[i] || "Live Web Search Result Context",
            domain: new URL(urls[i]).hostname.replace("www.", ""),
          });
        } catch {}
      }
      if (results.length > 0) return results;
    }
  } catch (e) {
    console.error("DuckDuckGo search error:", e);
  }

  return [
    {
      title: `Web search unavailable for "${query.slice(0, 35)}"`,
      url: "https://duckduckgo.com",
      snippet: "No live results could be retrieved. Answer from existing knowledge and say so.",
      domain: "duckduckgo.com",
    },
  ];
}

// ---------- /api/enhance-prompt ----------
async function enhancePrompt(body: any, signal?: AbortSignal): Promise<Response> {
  const { prompt, byok } = body;
  if (!prompt) return jsonResponse({ error: "Prompt is required" }, 400);
  const key = geminiKey(byok);
  if (!key) return jsonResponse({ error: "No API Key available for Gemini" }, 500);
  try {
    const r = await fetch(`${GEMINI_BASE}/models/gemini-3.6-flash:generateContent`, {
      method: "POST",
      signal,
      headers: { "Content-Type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify({
        contents: [
          {
            role: "user",
            parts: [
              {
                text: `You are an expert prompt engineer for advanced AI models. Enhance the following user prompt to make it clearer, more structured, and optimized for deep technical accuracy while preserving the original intent:\n\nOriginal Prompt: "${prompt}"\n\nReturn ONLY the enhanced prompt string without meta-commentary or wrapping quotes.`,
              },
            ],
          },
        ],
      }),
    });
    if (!r.ok) return jsonResponse({ error: `Gemini error ${r.status}: ${await r.text()}` }, 500);
    const data = await r.json();
    const text = (data.candidates?.[0]?.content?.parts || []).map((p: any) => p.text || "").join("").trim();
    return jsonResponse({ enhancedPrompt: text || prompt });
  } catch (e: any) {
    return jsonResponse({ error: e.message || "Failed to enhance prompt" }, 500);
  }
}

function jsonResponse(obj: unknown, status = 200) {
  return new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json" } });
}

// ---------- /api/chat (returns an SSE-formatted stream) ----------
function chat(body: any, signal?: AbortSignal): Response {
  const {
    modelId = "gemini-3.6-flash",
    prompt = "",
    systemPrompt = "You are an expert AI assistant.",
    temperature = 0.7,
    topP = 0.95,
    maxTokens = 2048,
    byok = {},
    image = null,
    enableSearch = false,
  } = body;

  const encoder = new TextEncoder();

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      let closed = false;
      const send = (d: Record<string, unknown>) => {
        if (!closed) controller.enqueue(encoder.encode(`data: ${JSON.stringify(d)}\n\n`));
      };
      const finish = () => {
        if (!closed) {
          closed = true;
          controller.close();
        }
      };
      const startTime = Date.now();
      const sendDone = (fullText: string) => {
        const elapsedMs = Math.max(1, Date.now() - startTime);
        const approxTokens = Math.max(1, Math.round(fullText.length / 4));
        send({ done: true, latencyMs: elapsedMs, tokensPerSec: Math.round(approxTokens / (elapsedMs / 1000)) });
      };

      // Gemini streaming (also used as the persona fallback for non-Gemini models)
      const streamGemini = async (key: string, model: string, system: string, deepseekThink: boolean) => {
        const r = await fetch(`${GEMINI_BASE}/models/${model}:streamGenerateContent?alt=sse`, {
          method: "POST",
          signal,
          headers: { "Content-Type": "application/json", "x-goog-api-key": key },
          body: JSON.stringify({
            contents: [{ role: "user", parts: buildParts(effectivePrompt, image) }],
            systemInstruction: { parts: [{ text: system }] },
            generationConfig: { temperature, topP },
          }),
        });
        if (!r.ok) {
          send({ error: `Gemini Error (${r.status}): ${await r.text()}` });
          send({ done: true });
          return;
        }
        let fullText = "";
        let sentVisible = 0;
        let sentReasoning = 0;
        await readSSE(r, (payload) => {
          try {
            const j = JSON.parse(payload);
            const text = (j.candidates?.[0]?.content?.parts || [])
              .filter((p: any) => !p.thought)
              .map((p: any) => p.text || "")
              .join("");
            if (!text) return;
            fullText += text;
            if (deepseekThink && fullText.includes("<think>")) {
              const s = fullText.indexOf("<think>");
              const e = fullText.indexOf("</think>");
              const reasoning = fullText.slice(s + 7, e === -1 ? undefined : e);
              const visible = fullText.slice(0, s) + (e === -1 ? "" : fullText.slice(e + 8));
              send({ chunk: visible.slice(sentVisible), reasoning: reasoning.slice(sentReasoning) });
              sentVisible = visible.length;
              sentReasoning = reasoning.length;
            } else {
              send({ chunk: fullText.slice(sentVisible) });
              sentVisible = fullText.length;
            }
          } catch {}
        });
        sendDone(fullText);
      };

      // OpenAI-compatible streaming (OpenRouter / Groq)
      const streamOpenAI = async (url: string, headers: Record<string, string>, model: string, label: string) => {
        const r = await fetch(url, {
          method: "POST",
          signal,
          headers: { ...headers, "Content-Type": "application/json" },
          body: JSON.stringify({
            model,
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: effectivePrompt },
            ],
            temperature,
            top_p: topP,
            max_tokens: maxTokens,
            stream: true,
          }),
        });
        if (!r.ok) {
          send({ error: `${label} Error (${r.status}): ${await r.text()}` });
          send({ done: true });
          return;
        }
        let fullText = "";
        await readSSE(r, (payload) => {
          if (payload === "[DONE]") return;
          try {
            const delta = JSON.parse(payload).choices?.[0]?.delta;
            const content = delta?.content || "";
            const reasoning = delta?.reasoning || "";
            if (content || reasoning) {
              fullText += content;
              send({ chunk: content, reasoning });
            }
          } catch {}
        });
        sendDone(fullText);
      };

      let effectivePrompt = prompt;
      try {
        if (enableSearch) {
          send({ isGrounding: true });
          const results = await performWebSearch(prompt, byok?.searchApiKey);
          send({ sources: results, isGrounding: false });
          const ctx = results
            .map((r, i) => `[Web Source ${i + 1}: ${r.title}] (${r.url})\nSummary: ${r.snippet}`)
            .join("\n\n");
          effectivePrompt = `[LIVE WEB GROUNDING CONTEXT]\n${ctx}\n\n[USER INSTRUCTION]\n${prompt}\n\nPlease synthesize the live web context above in your response, citing sources where applicable.`;
        }

        const gKey = geminiKey(byok);

        if (modelId.includes("gemini")) {
          if (!gKey) {
            send({ error: "Gemini API key is required. Add your key in BYOK Settings." });
            send({ done: true });
          } else {
            await streamGemini(gKey, geminiModelFor(modelId), systemPrompt, false);
          }
        } else if (byok?.openRouterApiKey) {
          const map: Record<string, string> = {
            "claude-3-5-sonnet": "anthropic/claude-3.5-sonnet",
            "gpt-4o": "openai/gpt-4o",
            "gpt-4o-mini": "openai/gpt-4o-mini",
            "llama-3-3-70b": "meta-llama/llama-3.3-70b-instruct",
            "deepseek-r1": "deepseek/deepseek-r1",
            "deepseek-v3": "deepseek/deepseek-chat",
          };
          await streamOpenAI(
            "https://openrouter.ai/api/v1/chat/completions",
            {
              Authorization: `Bearer ${byok.openRouterApiKey}`,
              "HTTP-Referer": "https://darkflux.ai",
              "X-Title": "Dark Flux AI Studio",
            },
            map[modelId] || modelId,
            "OpenRouter"
          );
        } else if (byok?.groqApiKey && /llama|mixtral|gemma/.test(modelId)) {
          const map: Record<string, string> = {
            "llama-3-3-70b": "llama-3.3-70b-versatile",
            "llama-3-1-8b": "llama-3.1-8b-instant",
          };
          await streamOpenAI(
            "https://api.groq.com/openai/v1/chat/completions",
            { Authorization: `Bearer ${byok.groqApiKey}` },
            map[modelId] || "llama-3.3-70b-versatile",
            "Groq"
          );
        } else if (gKey) {
          let persona = systemPrompt;
          if (modelId === "deepseek-r1")
            persona += `\n\nCRITICAL MODEL PERSONA: You are DeepSeek R1, a premier open-weights reasoning model. You MUST include your step-by-step reasoning chain inside a <think> ... </think> block at the very beginning of your response, detailing logical steps, edge cases, and self-corrections before providing the final answer.`;
          else if (modelId === "claude-3-5-sonnet")
            persona += `\n\nCRITICAL MODEL PERSONA: You are Claude 3.5 Sonnet by Anthropic. Your output is clean, highly analytical, exceptionally well-structured, and emphasizes software engineering best practices with type-safe, elegant code blocks.`;
          else if (modelId === "gpt-4o")
            persona += `\n\nCRITICAL MODEL PERSONA: You are GPT-4o by OpenAI. Provide direct, highly concise, punchy, and actionable responses with clean markdown lists and key highlights.`;
          else if (modelId === "llama-3-3-70b")
            persona += `\n\nCRITICAL MODEL PERSONA: You are Llama 3.3 70B Instruct by Meta AI. Provide blazingly fast, open-access, technical insights and code examples.`;
          await streamGemini(gKey, "gemini-3.6-flash", persona, modelId === "deepseek-r1");
        } else {
          send({ error: "No API key configured. Add a key in BYOK Settings." });
          send({ done: true });
        }
      } catch (err: any) {
        if (err?.name === "AbortError") {
          if (!closed) {
            closed = true;
            controller.error(new DOMException("Aborted", "AbortError"));
          }
          return;
        }
        send({ error: err?.message || "An error occurred during response generation." });
        send({ done: true });
      }
      finish();
    },
  });

  return new Response(stream, { status: 200, headers: { "Content-Type": "text/event-stream" } });
}

// ---------- public entry point ----------
export async function apiFetch(url: string, init: RequestInit = {}): Promise<Response> {
  const body = init.body ? JSON.parse(init.body as string) : {};
  const signal = init.signal as AbortSignal | undefined;
  if (url === "/api/chat") return chat(body, signal);
  if (url === "/api/enhance-prompt") return enhancePrompt(body, signal);
  if (url === "/api/health") return jsonResponse({ status: "ok", timestamp: new Date().toISOString() });
  return jsonResponse({ error: "Not found" }, 404);
}
