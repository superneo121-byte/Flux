import React, { useState } from "react";
import { X, Key, ShieldCheck, Eye, EyeOff, Check } from "lucide-react";
import { BYOKSettings } from "../types";

interface KeySettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  byok: BYOKSettings;
  onSaveKeys: (newKeys: BYOKSettings) => void;
}

export const KeySettingsModal: React.FC<KeySettingsModalProps> = ({
  isOpen,
  onClose,
  byok,
  onSaveKeys,
}) => {
  const [openRouterKey, setOpenRouterKey] = useState(byok.openRouterApiKey || "");
  const [groqKey, setGroqKey] = useState(byok.groqApiKey || "");
  const [geminiKey, setGeminiKey] = useState(byok.geminiApiKey || "");
  const [searchKey, setSearchKey] = useState(byok.searchApiKey || "");

  const [showOR, setShowOR] = useState(false);
  const [showGroq, setShowGroq] = useState(false);
  const [showGemini, setShowGemini] = useState(false);
  const [showSearch, setShowSearch] = useState(false);

  const [isSaved, setIsSaved] = useState(false);

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveKeys({
      openRouterApiKey: openRouterKey.trim() || undefined,
      groqApiKey: groqKey.trim() || undefined,
      geminiApiKey: geminiKey.trim() || undefined,
      searchApiKey: searchKey.trim() || undefined,
    });
    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
      onClose();
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 pt-[env(safe-area-inset-top)] bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg max-h-[92dvh] overflow-y-auto rounded-t-2xl sm:rounded-2xl bg-[#18181B] border border-white/[0.1] p-4 sm:p-6 pb-[calc(1rem+env(safe-area-inset-bottom))] shadow-2xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/[0.08]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-950/60 border border-cyan-500/40 text-cyan-400">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-zinc-100 font-sans">
                Bring Your Own Key (BYOK)
              </h3>
              <p className="text-xs text-zinc-400 font-mono">
                Keys remain encrypted strictly in local browser storage.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Inputs */}
        <div className="space-y-4">
          {/* OpenRouter Key */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-mono">
              <label className="text-zinc-300 font-semibold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-400" /> OpenRouter API Key
              </label>
              <a
                href="https://openrouter.ai/keys"
                target="_blank"
                rel="noreferrer"
                className="text-cyan-400 hover:underline text-[11px]"
              >
                Get Key
              </a>
            </div>
            <div className="relative">
              <input
                type={showOR ? "text" : "password"}
                value={openRouterKey}
                onChange={(e) => setOpenRouterKey(e.target.value)}
                placeholder="sk-or-v1-..."
                className="w-full bg-zinc-950 border border-white/[0.08] focus:border-cyan-500/60 rounded-xl px-3 py-2.5 pr-10 text-xs font-mono text-zinc-100 placeholder-zinc-600 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowOR(!showOR)}
                className="absolute right-3 top-3 text-zinc-500 hover:text-zinc-300"
              >
                {showOR ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-[10px] font-mono text-zinc-500">
              Unlocks Claude 3.5, GPT-4o, Llama 3.3, and DeepSeek models.
            </p>
          </div>

          {/* Groq Key */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-mono">
              <label className="text-zinc-300 font-semibold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-fuchsia-400" /> Groq API Key
              </label>
              <a
                href="https://console.groq.com/keys"
                target="_blank"
                rel="noreferrer"
                className="text-cyan-400 hover:underline text-[11px]"
              >
                Get Key
              </a>
            </div>
            <div className="relative">
              <input
                type={showGroq ? "text" : "password"}
                value={groqKey}
                onChange={(e) => setGroqKey(e.target.value)}
                placeholder="gsk_..."
                className="w-full bg-zinc-950 border border-white/[0.08] focus:border-cyan-500/60 rounded-xl px-3 py-2.5 pr-10 text-xs font-mono text-zinc-100 placeholder-zinc-600 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowGroq(!showGroq)}
                className="absolute right-3 top-3 text-zinc-500 hover:text-zinc-300"
              >
                {showGroq ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-[10px] font-mono text-zinc-500">
              Unlocks ultra-fast Llama 3.3 70B inference (200+ tk/s).
            </p>
          </div>

          {/* Custom Gemini Key */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-mono">
              <label className="text-zinc-300 font-semibold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-cyan-400" /> Custom Gemini API Key
              </label>
              <span className="text-[10px] font-mono text-emerald-400">Server Key Active by Default</span>
            </div>
            <div className="relative">
              <input
                type={showGemini ? "text" : "password"}
                value={geminiKey}
                onChange={(e) => setGeminiKey(e.target.value)}
                placeholder="AIzaSy..."
                className="w-full bg-zinc-950 border border-white/[0.08] focus:border-cyan-500/60 rounded-xl px-3 py-2.5 pr-10 text-xs font-mono text-zinc-100 placeholder-zinc-600 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowGemini(!showGemini)}
                className="absolute right-3 top-3 text-zinc-500 hover:text-zinc-300"
              >
                {showGemini ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-[10px] font-mono text-zinc-500">
              Optional: Override default server key with your personal Google AI Studio key.
            </p>
          </div>

          {/* Search API Key (Tavily / Serper / Web Grounding) */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-mono">
              <label className="text-zinc-300 font-semibold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400" /> Search API Key (Tavily / Serper)
              </label>
              <a
                href="https://tavily.com"
                target="_blank"
                rel="noreferrer"
                className="text-cyan-400 hover:underline text-[11px]"
              >
                Get Free Key
              </a>
            </div>
            <div className="relative">
              <input
                type={showSearch ? "text" : "password"}
                value={searchKey}
                onChange={(e) => setSearchKey(e.target.value)}
                placeholder="tvly-..."
                className="w-full bg-zinc-950 border border-white/[0.08] focus:border-cyan-500/60 rounded-xl px-3 py-2.5 pr-10 text-xs font-mono text-zinc-100 placeholder-zinc-600 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowSearch(!showSearch)}
                className="absolute right-3 top-3 text-zinc-500 hover:text-zinc-300"
              >
                {showSearch ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-[10px] font-mono text-zinc-500">
              Optional: Powers high-speed real-time web search grounding for all models. (DuckDuckGo fallback enabled by default).
            </p>
          </div>
        </div>

        {/* Security Info */}
        <div className="p-3 rounded-xl bg-zinc-950 border border-white/[0.06] flex items-start gap-2.5 text-xs text-zinc-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <p className="text-[11px] font-mono leading-relaxed">
            Your API keys never touch database storage. They pass directly over SSL to official model provider endpoints.
          </p>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-mono text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-cyan-400 text-zinc-950 font-mono font-bold text-xs hover:bg-cyan-300 shadow-[0_0_15px_rgba(0,229,255,0.4)] transition-all"
          >
            {isSaved ? (
              <>
                <Check className="w-4 h-4" /> Saved!
              </>
            ) : (
              "Save Keys"
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
