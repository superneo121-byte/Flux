import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { X, Copy, Check, Download, Cpu } from "lucide-react";
import { copyText, saveTextFile } from "../lib/native";
import { ModelRunResult } from "../types";
import { AVAILABLE_MODELS } from "../constants/models";

interface ExpandModalProps {
  result: ModelRunResult | null;
  onClose: () => void;
}

export const ExpandModal: React.FC<ExpandModalProps> = ({ result, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!result) return null;

  const spec = AVAILABLE_MODELS.find((m) => m.id === result.modelId);

  const handleCopy = () => {
    copyText(result.text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    saveTextFile(`${result.modelName.toLowerCase().replace(/\s+/g, "_")}_full.md`, result.text);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 pt-[env(safe-area-inset-top)] bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-4xl h-[92dvh] sm:h-[85vh] rounded-t-2xl sm:rounded-2xl pb-[env(safe-area-inset-bottom)] sm:pb-0 bg-[#18181B] border border-white/[0.1] shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 bg-zinc-900 border-b border-white/[0.08] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-950 border border-cyan-500/40 text-cyan-400">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-zinc-100 font-sans">{result.modelName}</h3>
                {spec?.badge && (
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${spec.tagColor}`}>
                    {spec.badge}
                  </span>
                )}
              </div>
              <p className="text-xs font-mono text-zinc-400">
                {result.provider} • Latency: {result.latencyMs ? `${result.latencyMs}ms` : "—"} • Speed: {result.tokensPerSec ? `${result.tokensPerSec} tk/s` : "—"}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-800 text-zinc-200 text-xs font-mono hover:bg-zinc-700 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? "Copied" : "Copy"}</span>
            </button>
            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-800 text-zinc-200 text-xs font-mono hover:bg-zinc-700 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span>Download</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 transition-colors ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 flex-1 overflow-y-auto overscroll-contain custom-scrollbar prose prose-invert max-w-none text-zinc-200 font-sans text-sm leading-relaxed">
          <ReactMarkdown remarkPlugins={[remarkGfm]}>{result.text}</ReactMarkdown>
        </div>
      </div>
    </div>
  );
};
