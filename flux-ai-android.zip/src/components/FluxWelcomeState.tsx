import React from "react";
import { Sparkles, Edit3, Code, Lightbulb, BarChart2, ArrowRight } from "lucide-react";

interface FluxWelcomeStateProps {
  onSelectPrompt: (promptText: string, autoRun?: boolean) => void;
}

export const FluxWelcomeState: React.FC<FluxWelcomeStateProps> = ({ onSelectPrompt }) => {
  const cards = [
    {
      icon: <Edit3 className="w-5 h-5 text-indigo-500 dark:text-indigo-400" />,
      title: "Write a report",
      subtitle: "Draft a Q3 summary based on notes",
      prompt: "Draft a comprehensive Q3 performance summary report based on project milestone notes.",
    },
    {
      icon: <Code className="w-5 h-5 text-emerald-500 dark:text-emerald-400" />,
      title: "Code a component",
      subtitle: "Build a React navbar with Tailwind",
      prompt: "Write a modern, accessible React navbar component using Tailwind CSS and TypeScript.",
    },
    {
      icon: <Lightbulb className="w-5 h-5 text-amber-500 dark:text-amber-400" />,
      title: "Brainstorm ideas",
      subtitle: "Marketing campaign for a new app",
      prompt: "Brainstorm 5 innovative viral marketing campaign strategies for launching a new AI mobile app.",
    },
    {
      icon: <BarChart2 className="w-5 h-5 text-rose-500 dark:text-rose-400" />,
      title: "Analyze data",
      subtitle: "Review user engagement metrics",
      prompt: "Analyze user retention and engagement metrics data to identify drop-off causes and solutions.",
    },
  ];

  return (
    <div className="flex flex-col items-center justify-center min-h-[460px] text-center gap-4 p-6 my-auto animate-fade-in max-w-3xl mx-auto">
      {/* Icon Box */}
      <div className="w-16 h-16 bg-indigo-500/10 dark:bg-indigo-600/20 border border-indigo-500/30 dark:border-indigo-500/40 rounded-2xl flex items-center justify-center mb-2 shadow-xl shadow-indigo-500/10 dark:shadow-indigo-950/50">
        <Sparkles className="w-8 h-8 text-indigo-600 dark:text-indigo-400 animate-pulse" />
      </div>

      {/* Main Title & Subtitle */}
      <h2 className="text-2xl sm:text-3xl font-bold font-sans text-zinc-900 dark:text-zinc-100 tracking-tight">
        How can I help you today?
      </h2>
      <p className="text-sm sm:text-base font-sans text-zinc-600 dark:text-zinc-400 max-w-md leading-relaxed">
        I am Flux AI. Let&apos;s explore ideas, compare multiple state-of-the-art models, write code, or analyze data together.
      </p>

      {/* 4 Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 mt-6 w-full max-w-2xl text-left">
        {cards.map((card, index) => (
          <button
            key={index}
            onClick={() => onSelectPrompt(card.prompt, false)}
            className="group flex flex-col items-start p-4 rounded-2xl border border-zinc-200 dark:border-white/[0.08] bg-white dark:bg-[#121318]/90 hover:bg-zinc-50 dark:hover:bg-[#181a22] hover:border-indigo-500/40 dark:hover:border-indigo-500/50 hover:shadow-md transition-all duration-200 shadow-sm relative overflow-hidden"
          >
            <div className="p-2 rounded-xl bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-white/[0.06] mb-3 group-hover:scale-110 transition-transform">
              {card.icon}
            </div>
            <div className="font-semibold text-sm font-sans text-zinc-900 dark:text-zinc-100 group-hover:text-indigo-600 dark:group-hover:text-indigo-300 transition-colors flex items-center justify-between w-full">
              <span>{card.title}</span>
              <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity text-indigo-500 dark:text-indigo-400 -translate-x-1 group-hover:translate-x-0" />
            </div>
            <p className="text-xs font-sans text-zinc-500 dark:text-zinc-400 mt-1">
              {card.subtitle}
            </p>
          </button>
        ))}
      </div>
    </div>
  );
};
