import React, { useRef, useState } from "react";
import {
  ArrowUp,
  Square,
  Globe,
  Brain,
  Plus,
  X,
  Wand2,
  Cpu,
} from "lucide-react";
import { AVAILABLE_MODELS } from "../constants/models";

interface FluxChatInputProps {
  prompt: string;
  setPrompt: (value: string) => void;
  onRunFlux: () => void;
  onStopFlux: () => void;
  isRunning: boolean;
  onEnhancePrompt: () => void;
  isEnhancing: boolean;
  attachedImage: string | null;
  setAttachedImage: (img: string | null) => void;
  enableSearch: boolean;
  setEnableSearch: (s: boolean) => void;
  selectedModelIds: string[];
  setSelectedModelIds: (ids: string[]) => void;
  onOpenSettings: () => void;
}

export const FluxChatInput: React.FC<FluxChatInputProps> = ({
  prompt,
  setPrompt,
  onRunFlux,
  onStopFlux,
  isRunning,
  onEnhancePrompt,
  isEnhancing,
  attachedImage,
  setAttachedImage,
  enableSearch,
  setEnableSearch,
  selectedModelIds,
  setSelectedModelIds,
  onOpenSettings,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showModelDropdown, setShowModelDropdown] = useState(false);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith("image/")) {
        alert("Please select a valid image file.");
        return;
      }
      const reader = new FileReader();
      reader.onload = (evt) => {
        setAttachedImage(evt.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
      e.preventDefault();
      if (isRunning) {
        onStopFlux();
      } else if (prompt.trim()) {
        onRunFlux();
      }
    } else if (e.key === "Enter" && !e.shiftKey && !window.matchMedia("(pointer: coarse)").matches) {
      // On touch screens Enter inserts a newline; the send button submits.
      e.preventDefault();
      if (isRunning) {
        onStopFlux();
      } else if (prompt.trim()) {
        onRunFlux();
      }
    }
  };

  const toggleModel = (id: string) => {
    if (selectedModelIds.includes(id)) {
      if (selectedModelIds.length > 1) {
        setSelectedModelIds(selectedModelIds.filter((m) => m !== id));
      }
    } else {
      setSelectedModelIds([...selectedModelIds, id]);
    }
  };

  const selectPreset = (type: "trio" | "all" | "reasoning" | "fast") => {
    if (type === "trio") {
      setSelectedModelIds(["gemini-3.6-flash", "claude-3-5-sonnet", "deepseek-r1"]);
    } else if (type === "all") {
      setSelectedModelIds(AVAILABLE_MODELS.map((m) => m.id));
    } else if (type === "reasoning") {
      setSelectedModelIds(["deepseek-r1", "gemini-3.1-pro", "claude-3-5-sonnet"]);
    } else if (type === "fast") {
      setSelectedModelIds(["gemini-3.6-flash", "gpt-4o-mini", "llama-3-1-8b"]);
    }
  };

  return (
    <div className="w-full max-w-[840px] mx-auto px-2.5 sm:px-4 pb-2 sm:pb-4 pt-1">
      {/* Input Outer Card */}
      <div className="bg-white dark:bg-[#121318] rounded-2xl shadow-xl border border-zinc-200 dark:border-white/[0.12] focus-within:border-indigo-500/60 focus-within:ring-3 focus-within:ring-indigo-500/15 transition-all p-2.5 flex flex-col relative">
        {/* Model Picker Popup Dropdown */}
        {showModelDropdown && (
          <div className="absolute bottom-full mb-3 left-0 right-0 p-3.5 rounded-2xl bg-white dark:bg-[#14151c] border border-zinc-200 dark:border-white/[0.1] shadow-2xl z-50 animate-fade-in font-mono text-xs">
            <div className="flex items-center justify-between pb-2 mb-2.5 border-b border-zinc-200 dark:border-white/[0.06] text-zinc-800 dark:text-zinc-300">
              <span className="font-semibold flex items-center gap-1.5 font-sans">
                <Cpu className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400" /> Target Models ({selectedModelIds.length} active):
              </span>
              <button
                onClick={() => setShowModelDropdown(false)}
                className="text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 cursor-pointer"
              >
                Close ✕
              </button>
            </div>

            {/* Quick Preset Buttons */}
            <div className="flex items-center gap-1.5 mb-3 flex-wrap">
              <span className="text-[10px] text-zinc-500 uppercase tracking-wider font-semibold mr-1">Presets:</span>
              <button
                onClick={() => selectPreset("trio")}
                className="px-2.5 py-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 text-zinc-700 dark:text-zinc-300 text-[10px] border border-zinc-200 dark:border-white/[0.06] cursor-pointer"
              >
                Top Trio
              </button>
              <button
                onClick={() => selectPreset("reasoning")}
                className="px-2.5 py-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 text-zinc-700 dark:text-zinc-300 text-[10px] border border-zinc-200 dark:border-white/[0.06] cursor-pointer"
              >
                Reasoning Tier
              </button>
              <button
                onClick={() => selectPreset("fast")}
                className="px-2.5 py-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 text-zinc-700 dark:text-zinc-300 text-[10px] border border-zinc-200 dark:border-white/[0.06] cursor-pointer"
              >
                Ultra Fast
              </button>
              <button
                onClick={() => selectPreset("all")}
                className="px-2.5 py-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 text-zinc-700 dark:text-zinc-300 text-[10px] border border-zinc-200 dark:border-white/[0.06] cursor-pointer"
              >
                Select All
              </button>
            </div>

            {/* Model Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-[38dvh] sm:max-h-56 overflow-y-auto custom-scrollbar p-0.5">
              {AVAILABLE_MODELS.map((m) => {
                const isSelected = selectedModelIds.includes(m.id);
                return (
                  <button
                    key={m.id}
                    onClick={() => toggleModel(m.id)}
                    className={`p-2.5 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                      isSelected
                        ? "bg-indigo-50 dark:bg-indigo-950/60 border-indigo-400 dark:border-indigo-500/50 text-indigo-900 dark:text-indigo-200 font-semibold"
                        : "bg-zinc-50 dark:bg-zinc-900/50 border-zinc-200 dark:border-white/[0.06] text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200"
                    }`}
                  >
                    <div className="truncate pr-1">
                      <div className="truncate text-xs font-sans">{m.name}</div>
                      <div className="text-[9px] text-zinc-400 font-mono">{m.provider}</div>
                    </div>
                    <span className={`w-2 h-2 rounded-full shrink-0 ${isSelected ? "bg-indigo-500 dark:bg-indigo-400" : "bg-zinc-300 dark:bg-zinc-700"}`} />
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Attachment Image Preview if uploaded */}
        {attachedImage && (
          <div className="mb-2 px-2 pt-1 flex items-center gap-2">
            <div className="relative group rounded-xl overflow-hidden border border-indigo-500/40 p-1 bg-zinc-100 dark:bg-zinc-900">
              <img src={attachedImage} alt="Attachment" className="w-12 h-12 object-cover rounded-lg" />
              <button
                onClick={() => setAttachedImage(null)}
                className="absolute top-1 right-1 p-0.5 rounded-full bg-black/80 text-white hover:bg-rose-600 transition-colors cursor-pointer"
                title="Remove attachment"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
            <span className="text-xs font-mono text-zinc-600 dark:text-zinc-400">Attached image for vision analysis</span>
          </div>
        )}

        {/* Textarea Input */}
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Message Flux AI or ask a question across models..."
          rows={2}
          className="w-full bg-transparent border-none focus:outline-none focus:ring-0 resize-none max-h-40 min-h-[52px] py-2 px-3 font-sans text-sm text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 dark:placeholder-zinc-500 leading-relaxed custom-scrollbar"
        />

        {/* Bottom Bar Tools */}
        <div className="flex justify-between items-center px-1 pt-2 border-t border-zinc-100 dark:border-white/[0.06] mt-1">
          <div className="flex items-center gap-1.5 flex-wrap min-w-0">
            {/* Attachment Button */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleImageUpload}
              accept="image/*"
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-2.5 sm:p-2 rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200 transition-colors cursor-pointer"
              title="Attach File / Image"
            >
              <Plus className="w-4 h-4" />
            </button>

            {/* Web Search Button */}
            <button
              type="button"
              onClick={() => setEnableSearch(!enableSearch)}
              className={`flex items-center gap-1.5 px-3 py-2 sm:py-1.5 rounded-xl border text-xs font-mono font-medium transition-all cursor-pointer ${
                enableSearch
                  ? "bg-emerald-50 dark:bg-emerald-950/80 border-emerald-400 dark:border-emerald-500/60 text-emerald-700 dark:text-emerald-300 shadow-sm"
                  : "bg-zinc-50 dark:bg-zinc-900/60 border-zinc-200 dark:border-white/[0.08] text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200"
              }`}
              title="Toggle Live Web Grounding / Search"
            >
              <Globe className={`w-3.5 h-3.5 ${enableSearch ? "text-emerald-500 dark:text-emerald-400 animate-pulse" : "text-zinc-400"}`} />
              <span className="hidden sm:inline">Web Search</span>
              <span className="sm:hidden">Search</span>
            </button>

            {/* Deep Think / Model Picker Button */}
            <button
              type="button"
              onClick={() => setShowModelDropdown(!showModelDropdown)}
              className={`flex items-center gap-1.5 px-3 py-2 sm:py-1.5 rounded-xl border text-xs font-mono font-medium transition-all cursor-pointer ${
                showModelDropdown
                  ? "bg-indigo-50 dark:bg-indigo-950 border-indigo-400 dark:border-indigo-500/60 text-indigo-700 dark:text-indigo-300"
                  : "bg-zinc-50 dark:bg-zinc-900/60 border-zinc-200 dark:border-white/[0.08] text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200"
              }`}
              title="Select AI Models"
            >
              <Brain className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400" />
              <span><span className="hidden sm:inline">Deep Think </span>({selectedModelIds.length})</span>
            </button>

            {/* Prompt Enhancer Button */}
            <button
              type="button"
              onClick={onEnhancePrompt}
              disabled={isEnhancing || !prompt.trim()}
              className="flex items-center gap-1.5 px-3 py-2 sm:px-2.5 sm:py-1.5 rounded-xl bg-zinc-50 dark:bg-zinc-900/60 border border-zinc-200 dark:border-white/[0.08] text-zinc-600 dark:text-zinc-400 hover:text-amber-600 dark:hover:text-amber-300 disabled:opacity-30 text-xs font-mono transition-colors cursor-pointer"
              title="Auto-Enhance Prompt with Gemini AI"
            >
              <Wand2 className={`w-3.5 h-3.5 ${isEnhancing ? "text-amber-500 animate-spin" : "text-amber-500 dark:text-amber-400"}`} />
              <span className="hidden sm:inline">Enhance</span>
            </button>
          </div>

          {/* Send / Stop Action Button */}
          {isRunning ? (
            <button
              type="button"
              onClick={onStopFlux}
              className="w-11 h-11 sm:w-9 sm:h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center hover:bg-rose-500 transition-colors shadow-md shadow-rose-600/30 cursor-pointer"
              title="Stop Generation"
            >
              <Square className="w-4 h-4 fill-current" />
            </button>
          ) : (
            <button
              type="button"
              onClick={onRunFlux}
              disabled={!prompt.trim()}
              className="w-11 h-11 sm:w-9 sm:h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center hover:bg-indigo-500 transition-colors shadow-md shadow-indigo-600/30 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
              title="Send Prompt (Enter)"
            >
              <ArrowUp className="w-4 h-4 stroke-[2.5]" />
            </button>
          )}
        </div>
      </div>

      {/* Footer Disclaimer */}
      <div className="hidden sm:block text-center mt-2">
        <span className="text-[11px] font-sans text-zinc-500 dark:text-zinc-500">
          Flux AI can make mistakes. Consider verifying important information.
        </span>
      </div>
    </div>
  );
};
