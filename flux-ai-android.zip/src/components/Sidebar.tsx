import React, { useState } from "react";
import {
  Sliders,
  Settings,
  Sparkles,
  Code2,
  GraduationCap,
  Zap,
  ShieldAlert,
  ChevronLeft,
  ChevronRight,
  Key,
  BookOpen,
  History,
  Check,
  RotateCcw
} from "lucide-react";
import { SYSTEM_PRESETS, PROMPT_TEMPLATES } from "../constants/presets";
import { BYOKSettings, SessionHistoryItem, PromptTemplate } from "../types";

interface SidebarProps {
  systemPrompt: string;
  setSystemPrompt: (prompt: string) => void;
  selectedPresetId: string;
  setSelectedPresetId: (id: string) => void;
  temperature: number;
  setTemperature: (val: number) => void;
  topP: number;
  setTopP: (val: number) => void;
  maxTokens: number;
  setMaxTokens: (val: number) => void;
  byok: BYOKSettings;
  onOpenBYOKModal: () => void;
  onOpenSettingsModal?: () => void;
  onSelectTemplate: (template: PromptTemplate) => void;
  history: SessionHistoryItem[];
  onLoadHistoryItem: (item: SessionHistoryItem) => void;
  isCollapsed: boolean;
  setIsCollapsed: (collapsed: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  systemPrompt,
  setSystemPrompt,
  selectedPresetId,
  setSelectedPresetId,
  temperature,
  setTemperature,
  topP,
  setTopP,
  maxTokens,
  setMaxTokens,
  byok,
  onOpenBYOKModal,
  onOpenSettingsModal,
  onSelectTemplate,
  history,
  onLoadHistoryItem,
  isCollapsed,
  setIsCollapsed,
}) => {
  const [activeTab, setActiveTab] = useState<"params" | "templates" | "history">("params");

  const handleSelectPreset = (presetId: string) => {
    setSelectedPresetId(presetId);
    const preset = SYSTEM_PRESETS.find((p) => p.id === presetId);
    if (preset) {
      setSystemPrompt(preset.systemPrompt);
    }
  };

  const getPresetIcon = (iconName: string) => {
    switch (iconName) {
      case "Code2":
        return <Code2 className="w-4 h-4 text-cyan-400" />;
      case "GraduationCap":
        return <GraduationCap className="w-4 h-4 text-violet-400" />;
      case "Zap":
        return <Zap className="w-4 h-4 text-amber-400" />;
      case "ShieldAlert":
        return <ShieldAlert className="w-4 h-4 text-rose-400" />;
      default:
        return <Sparkles className="w-4 h-4 text-emerald-400" />;
    }
  };

  if (isCollapsed) {
    return (
      <aside className="w-14 bg-[#09090B] border-r border-white/[0.08] flex flex-col items-center py-4 gap-6 select-none transition-all duration-300">
        <button
          onClick={() => setIsCollapsed(false)}
          className="p-2 rounded-lg bg-zinc-900 border border-white/[0.08] text-zinc-300 hover:text-cyan-400 hover:bg-zinc-800 transition-colors cursor-pointer"
          title="Expand Configurations Sidebar"
        >
          <ChevronRight className="w-5 h-5" />
        </button>

        <div className="flex flex-col gap-4">
          <button
            onClick={() => {
              setIsCollapsed(false);
              setActiveTab("params");
            }}
            className={`p-2 rounded-lg border transition-colors cursor-pointer ${
              activeTab === "params"
                ? "bg-cyan-950/40 border-cyan-500/50 text-cyan-300"
                : "border-transparent text-zinc-500 hover:text-zinc-300"
            }`}
            title="Model Hyperparameters"
          >
            <Sliders className="w-5 h-5" />
          </button>
          <button
            onClick={() => {
              setIsCollapsed(false);
              setActiveTab("templates");
            }}
            className={`p-2 rounded-lg border transition-colors cursor-pointer ${
              activeTab === "templates"
                ? "bg-cyan-950/40 border-cyan-500/50 text-cyan-300"
                : "border-transparent text-zinc-500 hover:text-zinc-300"
            }`}
            title="Prompt Templates"
          >
            <BookOpen className="w-5 h-5" />
          </button>
          <button
            onClick={() => {
              setIsCollapsed(false);
              setActiveTab("history");
            }}
            className={`p-2 rounded-lg border transition-colors cursor-pointer ${
              activeTab === "history"
                ? "bg-cyan-950/40 border-cyan-500/50 text-cyan-300"
                : "border-transparent text-zinc-500 hover:text-zinc-300"
            }`}
            title="Session History"
          >
            <History className="w-5 h-5" />
          </button>
          <button
            onClick={onOpenSettingsModal || onOpenBYOKModal}
            className="p-2 rounded-lg border border-cyan-500/30 bg-cyan-950/30 text-cyan-400 hover:bg-cyan-900/40 transition-colors cursor-pointer"
            title="All Settings & Themes"
          >
            <Settings className="w-5 h-5" />
          </button>
          <button
            onClick={onOpenBYOKModal}
            className="p-2 rounded-lg border border-emerald-500/30 bg-emerald-950/20 text-emerald-400 hover:bg-emerald-900/30 transition-colors cursor-pointer"
            title="BYOK API Keys"
          >
            <Key className="w-5 h-5" />
          </button>
        </div>
      </aside>
    );
  }

  return (
    <aside className="w-80 md:w-88 bg-[#09090B] border-r border-white/[0.08] flex flex-col h-[calc(100vh-61px)] overflow-hidden transition-all duration-300 select-none shrink-0">
      {/* Sidebar Header */}
      <div className="p-3 border-b border-white/[0.08] flex items-center justify-between bg-zinc-900/40">
        <div className="flex items-center gap-1.5 p-1 bg-zinc-950 rounded-lg border border-white/[0.06]">
          <button
            onClick={() => setActiveTab("params")}
            className={`px-3 py-1 rounded-md text-xs font-mono font-medium transition-all cursor-pointer ${
              activeTab === "params"
                ? "bg-zinc-800 text-cyan-300 shadow-sm"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            Config
          </button>
          <button
            onClick={() => setActiveTab("templates")}
            className={`px-3 py-1 rounded-md text-xs font-mono font-medium transition-all cursor-pointer ${
              activeTab === "templates"
                ? "bg-zinc-800 text-cyan-300 shadow-sm"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            Templates
          </button>
          <button
            onClick={() => setActiveTab("history")}
            className={`px-3 py-1 rounded-md text-xs font-mono font-medium transition-all cursor-pointer ${
              activeTab === "history"
                ? "bg-zinc-800 text-cyan-300 shadow-sm"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            History ({history.length})
          </button>
        </div>
        <button
          onClick={() => setIsCollapsed(true)}
          className="p-1.5 rounded-lg bg-zinc-900 border border-white/[0.08] text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 transition-colors cursor-pointer"
          title="Collapse Sidebar"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>

      {/* Sidebar Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 custom-scrollbar">
        {activeTab === "params" && (
          <>
            {/* BYOK Settings Banner */}
            <div
              onClick={onOpenBYOKModal}
              className="group p-3 rounded-xl bg-gradient-to-r from-zinc-900 to-zinc-900/90 border border-white/[0.08] hover:border-cyan-500/40 cursor-pointer transition-all shadow-sm"
            >
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-2">
                  <Key className="w-4 h-4 text-cyan-400 group-hover:rotate-12 transition-transform" />
                  <span className="text-xs font-mono font-semibold text-zinc-200">
                    BYOK Provider Keys
                  </span>
                </div>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400 group-hover:text-cyan-300">
                  Manage
                </span>
              </div>
              <p className="text-[11px] text-zinc-400 font-sans leading-relaxed">
                Connect OpenRouter, Groq, or custom Gemini keys for unlimited execution.
              </p>
            </div>

            {/* System Prompt Presets */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-mono font-medium uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-violet-400" />
                  System Persona Presets
                </label>
              </div>
              <div className="grid grid-cols-1 gap-1.5">
                {SYSTEM_PRESETS.map((preset) => {
                  const isSelected = selectedPresetId === preset.id;
                  return (
                    <button
                      key={preset.id}
                      onClick={() => handleSelectPreset(preset.id)}
                      className={`flex items-start gap-2.5 p-2.5 rounded-xl text-left border transition-all cursor-pointer ${
                        isSelected
                          ? "bg-gradient-to-r from-cyan-950/40 via-violet-950/20 to-zinc-900 border-cyan-500/50 text-zinc-100 shadow-[0_0_12px_rgba(0,229,255,0.08)]"
                          : "bg-zinc-900/60 border-white/[0.06] text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/80 hover:border-white/[0.12]"
                      }`}
                    >
                      <div className="mt-0.5 p-1 rounded-lg bg-zinc-800/80 border border-white/[0.08]">
                        {getPresetIcon(preset.iconName)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-medium text-zinc-200 font-sans">
                            {preset.name}
                          </span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                        </div>
                        <p className="text-[11px] text-zinc-400 truncate mt-0.5 font-sans">
                          {preset.description}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Custom System Prompt Textarea */}
              <div className="pt-2">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] font-mono text-zinc-400">System Instruction Text</span>
                  <button
                    onClick={() => setSystemPrompt(SYSTEM_PRESETS[0].systemPrompt)}
                    className="text-[10px] font-mono text-zinc-500 hover:text-cyan-400 flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" /> Reset
                  </button>
                </div>
                <textarea
                  value={systemPrompt}
                  onChange={(e) => setSystemPrompt(e.target.value)}
                  rows={4}
                  className="w-full bg-zinc-950 border border-white/[0.08] focus:border-cyan-500/60 rounded-xl p-2.5 text-xs text-zinc-200 font-mono resize-none focus:outline-none focus:ring-1 focus:ring-cyan-500/30 custom-scrollbar leading-relaxed"
                  placeholder="Enter system prompt instruction..."
                />
              </div>
            </div>

            <div className="h-[1px] bg-white/[0.08]" />

            {/* Hyperparameter Sliders */}
            <div className="space-y-5">
              <label className="text-xs font-mono font-medium uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-cyan-400" />
                Hyperparameters
              </label>

              {/* Temperature */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-zinc-300">Temperature</span>
                  <span className="px-2 py-0.5 rounded bg-zinc-900 border border-white/[0.08] text-cyan-400 font-semibold">
                    {temperature.toFixed(2)}
                  </span>
                </div>
                <input
                  type="range"
                  min={0.0}
                  max={2.0}
                  step={0.05}
                  value={temperature}
                  onChange={(e) => setTemperature(parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                />
                <div className="flex justify-between text-[10px] font-mono text-zinc-500">
                  <span>Exact / Deterministic (0.0)</span>
                  <span>Creative (2.0)</span>
                </div>
              </div>

              {/* Top-P */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-zinc-300">Top-P (Nucleus Sampling)</span>
                  <span className="px-2 py-0.5 rounded bg-zinc-900 border border-white/[0.08] text-violet-400 font-semibold">
                    {topP.toFixed(2)}
                  </span>
                </div>
                <input
                  type="range"
                  min={0.0}
                  max={1.0}
                  step={0.05}
                  value={topP}
                  onChange={(e) => setTopP(parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-violet-400"
                />
                <div className="flex justify-between text-[10px] font-mono text-zinc-500">
                  <span>Focused (0.1)</span>
                  <span>Diverse (1.0)</span>
                </div>
              </div>

              {/* Max Tokens */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-zinc-300">Max Tokens</span>
                  <span className="px-2 py-0.5 rounded bg-zinc-900 border border-white/[0.08] text-emerald-400 font-semibold">
                    {maxTokens}
                  </span>
                </div>
                <input
                  type="range"
                  min={256}
                  max={8192}
                  step={256}
                  value={maxTokens}
                  onChange={(e) => setMaxTokens(parseInt(e.target.value, 10))}
                  className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-400"
                />
                <div className="flex justify-between text-[10px] font-mono text-zinc-500">
                  <span>256</span>
                  <span>8192</span>
                </div>
              </div>
            </div>
          </>
        )}

        {activeTab === "templates" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-medium uppercase tracking-wider text-zinc-400">
                Prompt Templates
              </span>
              <span className="text-[11px] font-mono text-zinc-500">
                {PROMPT_TEMPLATES.length} presets
              </span>
            </div>
            <div className="space-y-2.5">
              {PROMPT_TEMPLATES.map((tmpl) => (
                <div
                  key={tmpl.id}
                  onClick={() => onSelectTemplate(tmpl)}
                  className="group p-3 rounded-xl bg-zinc-900/80 border border-white/[0.06] hover:border-cyan-500/40 hover:bg-zinc-800/80 cursor-pointer transition-all"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-medium text-zinc-200 group-hover:text-cyan-300 font-sans">
                      {tmpl.title}
                    </span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400 border border-white/[0.04]">
                      {tmpl.category}
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-400 line-clamp-2 leading-relaxed font-sans">
                    {tmpl.prompt}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "history" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-medium uppercase tracking-wider text-zinc-400">
                Session Runs
              </span>
              <span className="text-[11px] font-mono text-zinc-500">
                {history.length} saved
              </span>
            </div>
            {history.length === 0 ? (
              <div className="p-6 text-center border border-dashed border-zinc-800 rounded-xl">
                <History className="w-8 h-8 text-zinc-600 mx-auto mb-2" />
                <p className="text-xs text-zinc-400 font-mono">No past runs in session yet.</p>
                <p className="text-[11px] text-zinc-500 mt-1">Execute prompts in the arena to record history.</p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {history.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => onLoadHistoryItem(item)}
                    className="p-3 rounded-xl bg-zinc-900/80 border border-white/[0.06] hover:border-cyan-500/40 hover:bg-zinc-800/80 cursor-pointer transition-all"
                  >
                    <div className="flex items-center justify-between mb-1 text-[10px] font-mono text-zinc-500">
                      <span>{item.timestamp}</span>
                      <span className="text-cyan-400">{item.selectedModelIds.length} models</span>
                    </div>
                    <p className="text-xs font-medium text-zinc-200 line-clamp-2 font-sans">
                      {item.prompt}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </aside>
  );
};
