import React from "react";
import { AnimatedAIChat } from "./ui/animated-ai-chat";

interface StudioInputProps {
  prompt: string;
  setPrompt: (p: string) => void;
  selectedModelIds: string[];
  setSelectedModelIds: (ids: string[]) => void;
  onRunFlux: () => void;
  onStopFlux: () => void;
  isRunning: boolean;
  onEnhancePrompt: () => void;
  isEnhancing: boolean;
  viewMode: "grid" | "diff";
  setViewMode: (m: "grid" | "diff") => void;
  attachedImage: string | null;
  setAttachedImage: (img: string | null) => void;
  enableSearch: boolean;
  setEnableSearch: (s: boolean) => void;
  onOpenSettings?: () => void;
}

export const StudioInput: React.FC<StudioInputProps> = ({
  prompt,
  setPrompt,
  selectedModelIds,
  setSelectedModelIds,
  onRunFlux,
  onStopFlux,
  isRunning,
  onEnhancePrompt,
  isEnhancing,
  viewMode,
  setViewMode,
  attachedImage,
  setAttachedImage,
  enableSearch,
  setEnableSearch,
  onOpenSettings,
}) => {
  return (
    <div className="p-4 border-b border-white/[0.08] bg-transparent">
      <AnimatedAIChat
        prompt={prompt}
        setPrompt={setPrompt}
        selectedModelIds={selectedModelIds}
        setSelectedModelIds={setSelectedModelIds}
        onRunFlux={onRunFlux}
        onStopFlux={onStopFlux}
        isRunning={isRunning}
        onEnhancePrompt={onEnhancePrompt}
        isEnhancing={isEnhancing}
        viewMode={viewMode}
        setViewMode={setViewMode}
        attachedImage={attachedImage}
        setAttachedImage={setAttachedImage}
        enableSearch={enableSearch}
        setEnableSearch={setEnableSearch}
        onOpenSettings={onOpenSettings}
      />
    </div>
  );
};
