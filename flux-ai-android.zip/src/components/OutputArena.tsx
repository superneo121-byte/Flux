import { copyText, saveTextFile } from "../lib/native";
import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  Copy,
  Check,
  Download,
  Maximize2,
  RotateCcw,
  Clock,
  Zap,
  Brain,
  AlertCircle,
  ThumbsUp,
  ThumbsDown,
  ChevronDown,
  ChevronUp,
  Cpu,
  DollarSign,
  Globe,
  ExternalLink,
  Volume2,
  VolumeX,
} from "lucide-react";
import { ModelRunResult } from "../types";
import { AVAILABLE_MODELS } from "../constants/models";

interface OutputArenaProps {
  results: Record<string, ModelRunResult>;
  selectedModelIds: string[];
  onRegenerateModel: (modelId: string) => void;
  onOpenExpandModal: (result: ModelRunResult) => void;
}

export const OutputArena: React.FC<OutputArenaProps> = ({
  results,
  selectedModelIds,
  onRegenerateModel,
  onOpenExpandModal,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [expandedReasoning, setExpandedReasoning] = useState<Record<string, boolean>>({});
  const [expandedSources, setExpandedSources] = useState<Record<string, boolean>>({});
  const [speakingModelId, setSpeakingModelId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<Record<string, "up" | "down" | null>>({});

  const handleCopy = (modelId: string, text: string) => {
    copyText(text);
    setCopiedId(modelId);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDownload = (modelName: string, text: string) => {
    saveTextFile(`${modelName.toLowerCase().replace(/\s+/g, "_")}_output.md`, text);
  };

  const toggleReasoning = (modelId: string) => {
    setExpandedReasoning((prev) => ({
      ...prev,
      [modelId]: !prev[modelId],
    }));
  };

  const toggleSources = (modelId: string) => {
    setExpandedSources((prev) => ({
      ...prev,
      [modelId]: !prev[modelId],
    }));
  };

  const handleToggleSpeak = (modelId: string, text: string) => {
    if (!window.speechSynthesis) return;
    if (speakingModelId === modelId) {
      window.speechSynthesis.cancel();
      setSpeakingModelId(null);
      return;
    }
    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*_#`[\]()]/g, " ").replace(/\s+/g, " ").trim();
    const utterance = new SpeechSynthesisUtterance(cleanText.slice(0, 1500));
    utterance.rate = 1.0;
    utterance.onend = () => setSpeakingModelId(null);
    utterance.onerror = () => setSpeakingModelId(null);
    setSpeakingModelId(modelId);
    window.speechSynthesis.speak(utterance);
  };

  const handleVote = (modelId: string, vote: "up" | "down") => {
    setFeedback((prev) => ({
      ...prev,
      [modelId]: prev[modelId] === vote ? null : vote,
    }));
  };

  // Determine grid columns depending on how many models are selected
  const gridColsClass =
    selectedModelIds.length === 1
      ? "grid-cols-1 max-w-4xl mx-auto"
      : selectedModelIds.length === 2
      ? "grid-cols-1 lg:grid-cols-2"
      : "grid-cols-1 md:grid-cols-2 lg:grid-cols-3";

  return (
    <div className="p-2 sm:p-4">
      <div className={`grid gap-4 ${gridColsClass}`}>
        {selectedModelIds.map((modelId) => {
          const spec = AVAILABLE_MODELS.find((m) => m.id === modelId);
          const result = results[modelId] || {
            modelId,
            modelName: spec?.name || modelId,
            provider: spec?.provider || "AI",
            status: "idle",
            text: "",
          };

          const isStreaming = result.status === "streaming";
          const isGrounding = result.status === "grounding";
          const isCompleted = result.status === "completed";
          const isError = result.status === "error";
          const isReasoningExpanded = expandedReasoning[modelId] ?? true;
          const isSpeaking = speakingModelId === modelId;
          const currentVote = feedback[modelId];

          return (
            <div
              key={modelId}
              className={`flex flex-col justify-between rounded-2xl bg-white dark:bg-[#18181B] border transition-all shadow-md overflow-hidden ${
                isGrounding
                  ? "border-emerald-500/60 shadow-[0_0_20px_rgba(16,185,129,0.15)]"
                  : isStreaming
                  ? "border-indigo-500/60 shadow-[0_0_20px_rgba(99,102,241,0.12)]"
                  : isError
                  ? "border-rose-400 dark:border-rose-500/40"
                  : "border-zinc-200 dark:border-white/[0.08] hover:border-zinc-300 dark:hover:border-white/[0.14]"
              }`}
            >
              {/* Card Header */}
              <div className="p-3 bg-zinc-50 dark:bg-zinc-900/80 border-b border-zinc-200 dark:border-white/[0.08] flex flex-wrap items-center justify-between gap-2">
                {/* Left Model Identity */}
                <div className="flex items-center gap-2">
                  <div className="p-1 rounded-lg bg-zinc-100 dark:bg-zinc-950 border border-zinc-200 dark:border-white/[0.08]">
                    <Cpu className="w-4 h-4 text-indigo-500 dark:text-cyan-400" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-xs text-zinc-900 dark:text-zinc-100 font-sans">
                        {spec?.name || result.modelName}
                      </span>
                      {spec?.badge && (
                        <span className={`text-[9px] font-mono px-1.5 py-0.2 rounded border ${spec.tagColor}`}>
                          {spec.badge}
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] font-mono text-zinc-500 dark:text-zinc-400">
                      {spec?.provider} • {spec?.contextWindow}
                    </span>
                  </div>
                </div>

                {/* Right Actions & Status */}
                <div className="flex flex-wrap items-center gap-0.5 ml-auto">
                  {/* Status Pill */}
                  {isGrounding && (
                    <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-100 dark:bg-emerald-950 border border-emerald-300 dark:border-emerald-500/50 text-emerald-800 dark:text-emerald-300 shadow-sm animate-pulse">
                      <Globe className="w-3 h-3 text-emerald-600 dark:text-emerald-400 animate-spin" />
                      Searching...
                    </span>
                  )}
                  {isStreaming && !isGrounding && (
                    <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-mono bg-indigo-50 dark:bg-indigo-950/80 border border-indigo-200 dark:border-indigo-500/40 text-indigo-700 dark:text-indigo-300">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 dark:bg-indigo-400 animate-ping" />
                      Streaming...
                    </span>
                  )}
                  {isCompleted && (
                    <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-500/30 text-emerald-700 dark:text-emerald-300">
                      <Check className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                      Ready
                    </span>
                  )}
                  {isError && (
                    <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono bg-rose-50 dark:bg-rose-950/80 border border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300">
                      <AlertCircle className="w-3 h-3 text-rose-600 dark:text-rose-400" />
                      Error
                    </span>
                  )}

                  {/* Read Aloud / Speak Button */}
                  <button
                    onClick={() => handleToggleSpeak(modelId, result.text)}
                    disabled={!result.text}
                    className={`p-2 sm:p-1.5 rounded-lg transition-colors cursor-pointer ${
                      isSpeaking
                        ? "text-indigo-600 bg-indigo-50 dark:bg-indigo-950 dark:text-indigo-300"
                        : "text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 disabled:opacity-30"
                    }`}
                    title={isSpeaking ? "Stop Speaking" : "Read Aloud"}
                  >
                    {isSpeaking ? (
                      <VolumeX className="w-3.5 h-3.5 animate-pulse" />
                    ) : (
                      <Volume2 className="w-3.5 h-3.5" />
                    )}
                  </button>

                  {/* Copy Button */}
                  <button
                    onClick={() => handleCopy(modelId, result.text)}
                    disabled={!result.text}
                    className="p-2 sm:p-1.5 rounded-lg text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 disabled:opacity-30 transition-colors cursor-pointer"
                    title="Copy Output"
                  >
                    {copiedId === modelId ? (
                      <Check className="w-3.5 h-3.5 text-emerald-500 dark:text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>

                  {/* Download Markdown */}
                  <button
                    onClick={() => handleDownload(spec?.name || modelId, result.text)}
                    disabled={!result.text}
                    className="p-2 sm:p-1.5 rounded-lg text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 disabled:opacity-30 transition-colors cursor-pointer"
                    title="Download Markdown"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>

                  {/* Expand View */}
                  <button
                    onClick={() => onOpenExpandModal(result)}
                    disabled={!result.text}
                    className="p-2 sm:p-1.5 rounded-lg text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 disabled:opacity-30 transition-colors cursor-pointer"
                    title="Fullscreen Focus"
                  >
                    <Maximize2 className="w-3.5 h-3.5" />
                  </button>

                  {/* Regenerate */}
                  <button
                    onClick={() => onRegenerateModel(modelId)}
                    disabled={isStreaming}
                    className="p-2 sm:p-1.5 rounded-lg text-zinc-400 hover:text-indigo-600 dark:hover:text-cyan-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 disabled:opacity-30 transition-colors cursor-pointer"
                    title="Regenerate Output"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Card Body Output Stream */}
              <div className="p-4 flex-1 min-h-[200px] max-h-[65dvh] sm:max-h-[520px] overflow-y-auto overscroll-contain custom-scrollbar font-sans text-[13px] sm:text-xs text-zinc-800 dark:text-zinc-200 leading-relaxed space-y-3">
                {/* Active Web Grounding Loading Banner */}
                {isGrounding && (
                  <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-500/40 text-emerald-800 dark:text-emerald-300 flex items-center gap-2.5 animate-pulse text-xs font-mono">
                    <Globe className="w-4 h-4 text-emerald-600 dark:text-emerald-400 animate-spin shrink-0" />
                    <span>⚡ Fetching live context from the web...</span>
                  </div>
                )}

                {/* Reasoning Chain Collapsible Drawer */}
                {result.reasoning && (
                  <div className="rounded-xl bg-violet-50/70 dark:bg-zinc-950/80 border border-violet-200 dark:border-violet-500/30 overflow-hidden">
                    <button
                      onClick={() => toggleReasoning(modelId)}
                      className="w-full px-3 py-2 bg-violet-100/60 dark:bg-violet-950/30 flex items-center justify-between text-xs font-mono text-violet-800 dark:text-violet-300 hover:bg-violet-200/50 dark:hover:bg-violet-900/30 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-2">
                        <Brain className="w-3.5 h-3.5 text-violet-600 dark:text-violet-400 animate-pulse" />
                        <span className="font-semibold">Reasoning Process / Thinking Step</span>
                      </div>
                      {isReasoningExpanded ? (
                        <ChevronUp className="w-3.5 h-3.5" />
                      ) : (
                        <ChevronDown className="w-3.5 h-3.5" />
                      )}
                    </button>
                    {isReasoningExpanded && (
                      <div className="p-3 text-[11px] font-mono text-zinc-700 dark:text-zinc-400 leading-relaxed border-t border-violet-200 dark:border-violet-500/20 whitespace-pre-wrap bg-white/50 dark:bg-zinc-950">
                        {result.reasoning}
                      </div>
                    )}
                  </div>
                )}

                {/* Main Text Content */}
                {result.text ? (
                  <div className="space-y-3">
                    <div className="prose prose-neutral dark:prose-invert prose-xs max-w-none text-zinc-800 dark:text-zinc-200 font-sans leading-relaxed">
                      <ReactMarkdown
                        remarkPlugins={[remarkGfm]}
                        components={{
                          code({ node, inline, className, children, ...props }: any) {
                            const match = /language-(\w+)/.exec(className || "");
                            const codeText = String(children).replace(/\n$/, "");
                            if (!inline && match) {
                              return (
                                <div className="my-3 rounded-xl bg-zinc-900 text-zinc-100 border border-zinc-700 dark:border-white/[0.08] overflow-hidden">
                                  <div className="px-3 py-1.5 bg-zinc-950 border-b border-zinc-800 flex items-center justify-between text-[11px] font-mono text-zinc-400">
                                    <span className="text-cyan-400 font-semibold">{match[1]}</span>
                                    <button
                                      onClick={() => handleCopy(`${modelId}-code`, codeText)}
                                      className="flex items-center gap-1 text-[10px] text-zinc-400 hover:text-zinc-200 cursor-pointer"
                                    >
                                      <Copy className="w-3 h-3" /> Copy Snippet
                                    </button>
                                  </div>
                                  <pre className="p-3 overflow-x-auto text-[11px] font-mono text-zinc-200 leading-relaxed custom-scrollbar">
                                    <code>{children}</code>
                                  </pre>
                                </div>
                              );
                            }
                            return (
                              <code className="px-1.5 py-0.5 rounded bg-zinc-100 dark:bg-zinc-900 text-indigo-700 dark:text-cyan-300 font-mono text-[11px] border border-zinc-200 dark:border-white/[0.06]" {...props}>
                                {children}
                              </code>
                            );
                          },
                        }}
                      >
                        {result.text}
                      </ReactMarkdown>
                    </div>

                    {/* Sources Used Collapsible Section */}
                    {result.sources && result.sources.length > 0 && (
                      <div className="mt-4 pt-3 border-t border-zinc-200 dark:border-white/[0.08] space-y-2">
                        <button
                          onClick={() => toggleSources(modelId)}
                          className="flex items-center justify-between w-full text-xs font-mono text-emerald-600 dark:text-emerald-400 hover:underline font-semibold cursor-pointer"
                        >
                          <div className="flex items-center gap-1.5">
                            <Globe className="w-3.5 h-3.5" />
                            <span>🌐 Sources Used ({result.sources.length})</span>
                          </div>
                          {(expandedSources[modelId] ?? true) ? (
                            <ChevronUp className="w-3.5 h-3.5" />
                          ) : (
                            <ChevronDown className="w-3.5 h-3.5" />
                          )}
                        </button>
                        {(expandedSources[modelId] ?? true) && (
                          <div className="grid grid-cols-1 gap-1.5 pt-1">
                            {result.sources.map((src, idx) => (
                              <a
                                key={idx}
                                href={src.url}
                                target="_blank"
                                rel="noreferrer"
                                referrerPolicy="no-referrer"
                                className="group p-2 rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-emerald-200 dark:border-emerald-500/20 hover:border-emerald-400 dark:hover:border-emerald-500/50 flex items-start justify-between gap-2 text-[11px] font-mono transition-all"
                              >
                                <div className="space-y-0.5">
                                  <div className="font-semibold text-zinc-800 dark:text-zinc-200 group-hover:text-emerald-600 dark:group-hover:text-emerald-300 transition-colors line-clamp-1">
                                    {src.title}
                                  </div>
                                  {src.snippet && (
                                    <div className="text-[10px] text-zinc-500 dark:text-zinc-400 line-clamp-1 font-sans">
                                      {src.snippet}
                                    </div>
                                  )}
                                  <div className="text-[9px] text-emerald-600 dark:text-emerald-500/80">
                                    {src.domain || src.url}
                                  </div>
                                </div>
                                <ExternalLink className="w-3.5 h-3.5 text-zinc-400 group-hover:text-emerald-500 shrink-0 mt-0.5" />
                              </a>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ) : isStreaming ? (
                  <div className="space-y-2.5 pt-2">
                    <div className="h-3 bg-zinc-200 dark:bg-zinc-800 rounded animate-pulse w-3/4" />
                    <div className="h-3 bg-zinc-200 dark:bg-zinc-800 rounded animate-pulse w-full" />
                    <div className="h-3 bg-zinc-200 dark:bg-zinc-800 rounded animate-pulse w-5/6" />
                    <div className="h-3 bg-zinc-200 dark:bg-zinc-800 rounded animate-pulse w-2/3" />
                  </div>
                ) : isError ? (
                  <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-500/40 text-rose-800 dark:text-rose-300 text-xs font-mono space-y-1">
                    <div className="flex items-center gap-1.5 font-bold">
                      <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400" /> Generation Error
                    </div>
                    <p className="text-[11px] text-rose-700 dark:text-rose-200/80">{result.error || "Execution failed. Check BYOK keys or prompt constraints."}</p>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-36 text-center text-zinc-400 dark:text-zinc-600 font-mono text-xs">
                    <Zap className="w-6 h-6 mb-2 opacity-40 text-indigo-500 dark:text-cyan-400" />
                    <span>Awaiting Flux Execution...</span>
                  </div>
                )}
              </div>

              {/* Micro-Metrics Footer */}
              <div className="p-2.5 bg-zinc-50 dark:bg-zinc-950/90 border-t border-zinc-200 dark:border-white/[0.08] flex items-center justify-between text-[10px] font-mono text-zinc-500 dark:text-zinc-400">
                <div className="flex items-center gap-3">
                  {/* Latency */}
                  <div className="flex items-center gap-1" title="Initial Latency / Time to First Chunk">
                    <Clock className="w-3 h-3 text-indigo-500 dark:text-cyan-400" />
                    <span className="hidden sm:inline">Latency:</span>
                    <span className="text-zinc-800 dark:text-zinc-200 font-semibold">
                      {result.latencyMs ? `${result.latencyMs}ms` : spec?.estLatencyMs ? `~${spec.estLatencyMs}ms` : "—"}
                    </span>
                  </div>

                  {/* Speed */}
                  <div className="flex items-center gap-1" title="Generation Velocity">
                    <Zap className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                    <span className="hidden sm:inline">Speed:</span>
                    <span className="text-zinc-800 dark:text-zinc-200 font-semibold">
                      {result.tokensPerSec ? `${result.tokensPerSec} tk/s` : spec?.estTokensPerSec ? `~${spec.estTokensPerSec} tk/s` : "—"}
                    </span>
                  </div>

                  {/* Est Cost */}
                  <div className="hidden sm:flex items-center gap-1" title="Estimated Query Cost">
                    <DollarSign className="w-3 h-3 text-violet-600 dark:text-violet-400" />
                    <span>Est:</span>
                    <span className="text-zinc-800 dark:text-zinc-200 font-semibold">{spec?.costPer1k || "$0.0001"}</span>
                  </div>
                </div>

                {/* Rating Thumbs */}
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleVote(modelId, "up")}
                    className={`p-1 rounded transition-colors cursor-pointer ${
                      currentVote === "up"
                        ? "text-emerald-600 bg-emerald-50 dark:bg-emerald-950/80"
                        : "text-zinc-400 hover:text-emerald-500"
                    }`}
                    title="Good response"
                  >
                    <ThumbsUp className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() => handleVote(modelId, "down")}
                    className={`p-1 rounded transition-colors cursor-pointer ${
                      currentVote === "down"
                        ? "text-rose-600 bg-rose-50 dark:bg-rose-950/80"
                        : "text-zinc-400 hover:text-rose-500"
                    }`}
                    title="Poor response"
                  >
                    <ThumbsDown className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
