import React from "react";
import { X, Command } from "lucide-react";

interface ShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShortcutsModal: React.FC<ShortcutsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const shortcuts = [
    { key: "⌘ + Enter / Ctrl + Enter", desc: "Execute prompt across all selected arena models" },
    { key: "Esc", desc: "Close open modals or clear current focus" },
    { key: "Alt + C", desc: "Clear active studio output workspace" },
    { key: "Alt + B", desc: "Toggle BYOK Key Management dialog" },
    { key: "Alt + T", desc: "Cycle system prompt persona presets" },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 pt-[calc(1rem+env(safe-area-inset-top))] bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-md rounded-2xl bg-[#18181B] border border-white/[0.1] p-6 shadow-2xl space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
          <div className="flex items-center gap-2">
            <Command className="w-5 h-5 text-cyan-400" />
            <h3 className="text-base font-bold text-zinc-100 font-sans">Keyboard Shortcuts</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-2.5">
          {shortcuts.map((sc, idx) => (
            <div
              key={idx}
              className="p-3 rounded-xl bg-zinc-950 border border-white/[0.06] flex items-center justify-between"
            >
              <span className="text-xs font-sans text-zinc-300">{sc.desc}</span>
              <kbd className="px-2 py-1 rounded bg-zinc-800 text-[11px] font-mono font-semibold text-cyan-300 border border-white/[0.1]">
                {sc.key}
              </kbd>
            </div>
          ))}
        </div>

        <div className="pt-2 text-center">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-mono font-bold text-zinc-200 transition-colors"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
