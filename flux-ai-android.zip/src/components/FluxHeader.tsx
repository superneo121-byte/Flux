import React from "react";
import {
  Menu,
  Sun,
  Moon,
  Monitor,
  Settings,
  LayoutGrid,
  Columns,
  Zap,
  Download,
  Trash2,
  HelpCircle,
} from "lucide-react";
import { BYOKSettings, SessionHistoryItem } from "../types";

interface FluxHeaderProps {
  isSidebarOpen: boolean;
  onToggleSidebar: () => void;
  themeMode: "light" | "dark" | "system";
  setThemeMode: (mode: "light" | "dark" | "system") => void;
  onOpenSettingsModal: () => void;
  byok: BYOKSettings;
  onClearSession: () => void;
  onExportSession: () => void;
  activeSessionHistory: SessionHistoryItem[];
  onShowShortcuts: () => void;
  viewMode?: "grid" | "diff";
  setViewMode?: (mode: "grid" | "diff") => void;
  hasResults?: boolean;
}

export const FluxHeader: React.FC<FluxHeaderProps> = ({
  onToggleSidebar,
  themeMode,
  setThemeMode,
  onOpenSettingsModal,
  onClearSession,
  onExportSession,
  onShowShortcuts,
  viewMode = "grid",
  setViewMode,
  hasResults = false,
}) => {
  const cycleTheme = () =>
    setThemeMode(themeMode === "light" ? "dark" : themeMode === "dark" ? "system" : "light");
  const ThemeIcon = themeMode === "light" ? Sun : themeMode === "dark" ? Moon : Monitor;

  const iconBtn =
    "p-2.5 sm:p-2 rounded-xl text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100 hover:bg-zinc-100 dark:hover:bg-zinc-800/60 active:bg-zinc-200 dark:active:bg-zinc-800 transition-colors cursor-pointer flex items-center justify-center";

  const segBtn = (active: boolean) =>
    `flex-1 md:flex-none flex items-center justify-center gap-1.5 px-3 py-1.5 md:py-1 rounded-lg transition-all cursor-pointer ${
      active
        ? "bg-white dark:bg-indigo-600 text-zinc-900 dark:text-white shadow-sm font-semibold"
        : "text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200"
    }`;

  const switcher = setViewMode && (
    <div className="flex items-center bg-zinc-100 dark:bg-zinc-900/90 border border-zinc-200 dark:border-white/[0.08] rounded-xl p-1 text-xs font-mono">
      <button onClick={() => setViewMode("grid")} className={segBtn(viewMode === "grid")}>
        <LayoutGrid className="w-3.5 h-3.5" />
        <span>Grid Arena</span>
      </button>
      <button onClick={() => setViewMode("diff")} className={segBtn(viewMode === "diff")}>
        <Columns className="w-3.5 h-3.5" />
        <span>Diff Compare</span>
      </button>
    </div>
  );

  return (
    <header className="relative z-50 shrink-0 pt-[env(safe-area-inset-top)] bg-white/95 dark:bg-[#0c0d11]/95 backdrop-blur-md border-b border-zinc-200 dark:border-white/[0.08] transition-colors duration-200">
      <div className="h-14 sm:h-16 px-2 sm:px-4 flex justify-between items-center gap-2">
        {/* Left: Menu toggle + Brand */}
        <div className="flex items-center gap-1 sm:gap-3 min-w-0">
          <button onClick={onToggleSidebar} className={iconBtn} title="Toggle Navigation Sidebar" aria-label="Menu">
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 shrink-0 rounded-xl bg-indigo-600/10 dark:bg-indigo-600/20 border border-indigo-500/30 dark:border-indigo-500/40 flex items-center justify-center shadow-[0_0_12px_rgba(99,102,241,0.2)]">
              <Zap className="w-4 h-4 fill-indigo-500 dark:fill-indigo-400 text-indigo-600 dark:text-indigo-400" />
            </div>
            <h1 className="font-bold text-base sm:text-xl text-zinc-900 dark:text-zinc-100 tracking-tight font-sans flex items-center gap-2 truncate">
              Flux AI
              <span className="hidden lg:inline-block text-[10px] font-mono px-2 py-0.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-600 dark:text-indigo-300 font-normal">
                v2.5 Studio
              </span>
            </h1>
          </div>
        </div>

        {/* Center: view switcher (tablet / desktop) */}
        {hasResults && switcher && <div className="hidden md:block">{switcher}</div>}

        {/* Right actions */}
        <div className="flex items-center gap-0.5 sm:gap-2 shrink-0">
          {hasResults && (
            <>
              <button onClick={onExportSession} className={iconBtn} title="Export Conversation (JSON)" aria-label="Export">
                <Download className="w-4 h-4" />
              </button>
              <button
                onClick={onClearSession}
                className={`${iconBtn} hover:!text-rose-500`}
                title="Clear Session"
                aria-label="Clear"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </>
          )}

          {/* Phones: one button that cycles the theme */}
          <button onClick={cycleTheme} className={`${iconBtn} sm:hidden`} title={`Theme: ${themeMode}`} aria-label="Change theme">
            <ThemeIcon className="w-4 h-4" />
          </button>

          {/* Tablets+: full theme toggle group */}
          <div className="hidden sm:flex items-center bg-zinc-100 dark:bg-zinc-900/90 border border-zinc-200 dark:border-white/[0.08] rounded-full p-1">
            {(
              [
                ["light", Sun],
                ["dark", Moon],
                ["system", Monitor],
              ] as const
            ).map(([mode, Icon]) => (
              <button
                key={mode}
                onClick={() => setThemeMode(mode)}
                className={`p-1.5 rounded-full transition-all cursor-pointer ${
                  themeMode === mode
                    ? mode === "light"
                      ? "bg-white text-indigo-600 shadow-sm"
                      : "bg-indigo-600 text-white shadow-sm"
                    : "text-zinc-500 dark:text-zinc-400 hover:text-zinc-800 dark:hover:text-zinc-200"
                }`}
                title={`${mode} mode`}
              >
                <Icon className="w-3.5 h-3.5" />
              </button>
            ))}
          </div>

          <button onClick={onShowShortcuts} className={`${iconBtn} hidden md:flex`} title="Keyboard Shortcuts">
            <HelpCircle className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenSettingsModal}
            className="flex items-center gap-1.5 p-2.5 sm:px-3 sm:py-1.5 rounded-xl font-mono text-xs font-semibold bg-indigo-50 dark:bg-indigo-600/15 hover:bg-indigo-100 dark:hover:bg-indigo-600/25 border border-indigo-200 dark:border-indigo-500/40 text-indigo-700 dark:text-indigo-300 shadow-sm transition-all cursor-pointer ml-0.5"
            title="Settings: API keys, themes, models & storage"
            aria-label="Settings"
          >
            <Settings className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            <span className="hidden sm:inline">Settings</span>
          </button>
        </div>
      </div>

      {/* Phones: view switcher on its own row */}
      {hasResults && switcher && <div className="md:hidden px-3 pb-2">{switcher}</div>}
    </header>
  );
};
