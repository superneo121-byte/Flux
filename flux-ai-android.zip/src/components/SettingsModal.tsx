import React, { useState } from "react";
import {
  X,
  Key,
  ShieldCheck,
  Eye,
  EyeOff,
  Sliders,
  Palette,
  Database,
  Check,
  RotateCcw,
  Sparkles,
  Settings,
  Cpu,
  Download,
  Trash2
} from "lucide-react";
import { BYOKSettings } from "../types";
import { SYSTEM_PRESETS } from "../constants/presets";

export interface ThemeConfig {
  id: string;
  name: string;
  bgHex: string;
  cardHex: string;
  accent: string;
  previewClass: string;
}

export const THEME_PRESETS: ThemeConfig[] = [
  {
    id: "obsidian",
    name: "Ultra Obsidian",
    bgHex: "#09090B",
    cardHex: "#18181B",
    accent: "cyan",
    previewClass: "from-[#09090B] to-[#18181B] border-cyan-500/50"
  },
  {
    id: "midnight",
    name: "Midnight Sapphire",
    bgHex: "#0A0E1A",
    cardHex: "#13192B",
    accent: "blue",
    previewClass: "from-[#0A0E1A] to-[#13192B] border-blue-500/50"
  },
  {
    id: "amethyst",
    name: "Amethyst Neon",
    bgHex: "#120A1C",
    cardHex: "#1D132B",
    accent: "violet",
    previewClass: "from-[#120A1C] to-[#1D132B] border-violet-500/50"
  },
  {
    id: "slate",
    name: "Deep Slate",
    bgHex: "#0F172A",
    cardHex: "#1E293B",
    accent: "emerald",
    previewClass: "from-[#0F172A] to-[#1E293B] border-emerald-500/50"
  },
  {
    id: "oled",
    name: "Pure OLED Pitch",
    bgHex: "#000000",
    cardHex: "#121212",
    accent: "amber",
    previewClass: "from-[#000000] to-[#121212] border-amber-500/50"
  }
];

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  byok: BYOKSettings;
  onSaveKeys: (newKeys: BYOKSettings) => void;
  currentThemeId: string;
  setThemeId: (id: string) => void;
  temperature: number;
  setTemperature: (v: number) => void;
  topP: number;
  setTopP: (v: number) => void;
  maxTokens: number;
  setMaxTokens: (v: number) => void;
  systemPrompt: string;
  setSystemPrompt: (s: string) => void;
  selectedPresetId: string;
  setSelectedPresetId: (id: string) => void;
  onClearSession: () => void;
  onExportSession: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  byok,
  onSaveKeys,
  currentThemeId,
  setThemeId,
  temperature,
  setTemperature,
  topP,
  setTopP,
  maxTokens,
  setMaxTokens,
  systemPrompt,
  setSystemPrompt,
  selectedPresetId,
  setSelectedPresetId,
  onClearSession,
  onExportSession,
}) => {
  const [activeTab, setActiveTab] = useState<"keys" | "theme" | "model" | "data">("keys");

  // Local state for keys
  const [openRouterKey, setOpenRouterKey] = useState(byok.openRouterApiKey || "");
  const [groqKey, setGroqKey] = useState(byok.groqApiKey || "");
  const [geminiKey, setGeminiKey] = useState(byok.geminiApiKey || "");
  const [searchKey, setSearchKey] = useState(byok.searchApiKey || "");

  const [showOR, setShowOR] = useState(false);
  const [showGroq, setShowGroq] = useState(false);
  const [showGemini, setShowGemini] = useState(false);
  const [showSearch, setShowSearch] = useState(false);

  const [isSaved, setIsSaved] = useState(false);

  if (!isOpen) return null;

  const handleSaveKeys = () => {
    onSaveKeys({
      openRouterApiKey: openRouterKey.trim() || undefined,
      groqApiKey: groqKey.trim() || undefined,
      geminiApiKey: geminiKey.trim() || undefined,
      searchApiKey: searchKey.trim() || undefined,
    });
    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
    }, 1500);
  };

  const handleResetDefaults = () => {
    setTemperature(0.7);
    setTopP(0.95);
    setMaxTokens(2048);
    const defaultPreset = SYSTEM_PRESETS[0];
    if (defaultPreset) {
      setSelectedPresetId(defaultPreset.id);
      setSystemPrompt(defaultPreset.systemPrompt);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 pt-[env(safe-area-inset-top)] bg-black/85 backdrop-blur-md animate-fade-in select-text">
      <div className="relative w-full max-w-2xl rounded-t-2xl sm:rounded-2xl bg-[#141417] border border-white/[0.1] shadow-2xl overflow-hidden flex flex-col max-h-[92dvh] sm:max-h-[90vh] pb-[env(safe-area-inset-bottom)] sm:pb-0">
        {/* Modal Header */}
        <div className="p-4 bg-zinc-900/90 border-b border-white/[0.08] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-950 border border-cyan-500/40 text-cyan-400">
              <Settings className="w-5 h-5 animate-spin-slow" />
            </div>
            <div>
              <h3 className="text-base font-bold text-zinc-100 font-sans flex items-center gap-2">
                Studio Settings & Configuration
              </h3>
              <p className="hidden sm:block text-xs text-zinc-400 font-mono">
                Manage API keys, visual themes, parameters, and workspace storage
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2.5 sm:p-1.5 rounded-xl text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 p-2 bg-zinc-950 border-b border-white/[0.06] shrink-0 font-mono text-xs overflow-x-auto custom-scrollbar">
          <button
            onClick={() => setActiveTab("keys")}
            className={`shrink-0 whitespace-nowrap flex items-center gap-1.5 px-3.5 py-2.5 sm:py-2 rounded-xl font-semibold transition-all ${
              activeTab === "keys"
                ? "bg-cyan-950 border border-cyan-500/50 text-cyan-300 shadow-[0_0_10px_rgba(0,229,255,0.15)]"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900"
            }`}
          >
            <Key className="w-3.5 h-3.5 text-cyan-400" />
            <span>API Keys (BYOK)</span>
          </button>
          <button
            onClick={() => setActiveTab("theme")}
            className={`shrink-0 whitespace-nowrap flex items-center gap-1.5 px-3.5 py-2.5 sm:py-2 rounded-xl font-semibold transition-all ${
              activeTab === "theme"
                ? "bg-violet-950 border border-violet-500/50 text-violet-300 shadow-[0_0_10px_rgba(168,85,247,0.15)]"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900"
            }`}
          >
            <Palette className="w-3.5 h-3.5 text-violet-400" />
            <span>Themes & Styling</span>
          </button>
          <button
            onClick={() => setActiveTab("model")}
            className={`shrink-0 whitespace-nowrap flex items-center gap-1.5 px-3.5 py-2.5 sm:py-2 rounded-xl font-semibold transition-all ${
              activeTab === "model"
                ? "bg-amber-950 border border-amber-500/50 text-amber-300 shadow-[0_0_10px_rgba(245,158,11,0.15)]"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900"
            }`}
          >
            <Sliders className="w-3.5 h-3.5 text-amber-400" />
            <span>Hyperparameters</span>
          </button>
          <button
            onClick={() => setActiveTab("data")}
            className={`shrink-0 whitespace-nowrap flex items-center gap-1.5 px-3.5 py-2.5 sm:py-2 rounded-xl font-semibold transition-all ${
              activeTab === "data"
                ? "bg-emerald-950 border border-emerald-500/50 text-emerald-300 shadow-[0_0_10px_rgba(16,185,129,0.15)]"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900"
            }`}
          >
            <Database className="w-3.5 h-3.5 text-emerald-400" />
            <span>Data & Storage</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto overscroll-contain custom-scrollbar flex-1 space-y-5">
          {/* TAB 1: API KEYS */}
          {activeTab === "keys" && (
            <div className="space-y-4">
              <div className="p-3 rounded-xl bg-zinc-900/80 border border-white/[0.08] flex items-start gap-2.5 text-xs text-zinc-300 font-mono">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <p>
                  Keys are saved safely in your browser&apos;s local encrypted cache. They are never sent to third-party databases.
                </p>
              </div>

              {/* OpenRouter Key */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-mono">
                  <label className="text-zinc-200 font-semibold flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-amber-400" /> OpenRouter API Key
                  </label>
                  <a
                    href="https://openrouter.ai/keys"
                    target="_blank"
                    rel="noreferrer"
                    className="text-cyan-400 hover:underline text-[11px]"
                  >
                    Get Key
                  </a>
                </div>
                <div className="relative">
                  <input
                    type={showOR ? "text" : "password"}
                    value={openRouterKey}
                    onChange={(e) => setOpenRouterKey(e.target.value)}
                    placeholder="sk-or-v1-..."
                    className="w-full bg-zinc-950 border border-white/[0.1] focus:border-cyan-500/60 rounded-xl px-3 py-2.5 pr-10 text-xs font-mono text-zinc-100 placeholder-zinc-600 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowOR(!showOR)}
                    className="absolute right-3 top-3 text-zinc-500 hover:text-zinc-300"
                  >
                    {showOR ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-[10px] font-mono text-zinc-500">
                  Unlocks Claude 3.5 Sonnet, GPT-4o, DeepSeek R1, and Llama 3.3 models.
                </p>
              </div>

              {/* Groq Key */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-mono">
                  <label className="text-zinc-200 font-semibold flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-fuchsia-400" /> Groq API Key
                  </label>
                  <a
                    href="https://console.groq.com/keys"
                    target="_blank"
                    rel="noreferrer"
                    className="text-cyan-400 hover:underline text-[11px]"
                  >
                    Get Key
                  </a>
                </div>
                <div className="relative">
                  <input
                    type={showGroq ? "text" : "password"}
                    value={groqKey}
                    onChange={(e) => setGroqKey(e.target.value)}
                    placeholder="gsk_..."
                    className="w-full bg-zinc-950 border border-white/[0.1] focus:border-cyan-500/60 rounded-xl px-3 py-2.5 pr-10 text-xs font-mono text-zinc-100 placeholder-zinc-600 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowGroq(!showGroq)}
                    className="absolute right-3 top-3 text-zinc-500 hover:text-zinc-300"
                  >
                    {showGroq ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-[10px] font-mono text-zinc-500">
                  Unlocks ultra-fast LPUs for Llama 3.3 70B (200+ tk/s streaming).
                </p>
              </div>

              {/* Gemini Key */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-mono">
                  <label className="text-zinc-200 font-semibold flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-cyan-400" /> Custom Gemini API Key
                  </label>
                  <span className="text-[10px] font-mono text-emerald-400">Server Key Active</span>
                </div>
                <div className="relative">
                  <input
                    type={showGemini ? "text" : "password"}
                    value={geminiKey}
                    onChange={(e) => setGeminiKey(e.target.value)}
                    placeholder="AIzaSy..."
                    className="w-full bg-zinc-950 border border-white/[0.1] focus:border-cyan-500/60 rounded-xl px-3 py-2.5 pr-10 text-xs font-mono text-zinc-100 placeholder-zinc-600 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowGemini(!showGemini)}
                    className="absolute right-3 top-3 text-zinc-500 hover:text-zinc-300"
                  >
                    {showGemini ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-[10px] font-mono text-zinc-500">
                  Optional: Override default server key with your personal Google AI Studio key.
                </p>
              </div>

              {/* Search API Key */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-mono">
                  <label className="text-zinc-200 font-semibold flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" /> Search API Key (Tavily / Serper)
                  </label>
                  <a
                    href="https://tavily.com"
                    target="_blank"
                    rel="noreferrer"
                    className="text-cyan-400 hover:underline text-[11px]"
                  >
                    Get Key
                  </a>
                </div>
                <div className="relative">
                  <input
                    type={showSearch ? "text" : "password"}
                    value={searchKey}
                    onChange={(e) => setSearchKey(e.target.value)}
                    placeholder="tvly-..."
                    className="w-full bg-zinc-950 border border-white/[0.1] focus:border-cyan-500/60 rounded-xl px-3 py-2.5 pr-10 text-xs font-mono text-zinc-100 placeholder-zinc-600 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowSearch(!showSearch)}
                    className="absolute right-3 top-3 text-zinc-500 hover:text-zinc-300"
                  >
                    {showSearch ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-[10px] font-mono text-zinc-500">
                  Powers instant live internet search grounding for all models (DuckDuckGo enabled as default fallback).
                </p>
              </div>

              <div className="pt-2">
                <button
                  onClick={handleSaveKeys}
                  className="w-full py-2.5 rounded-xl bg-cyan-400 text-zinc-950 font-mono font-bold text-xs hover:bg-cyan-300 shadow-[0_0_15px_rgba(0,229,255,0.3)] transition-all flex items-center justify-center gap-1.5"
                >
                  {isSaved ? <Check className="w-4 h-4" /> : <Key className="w-4 h-4" />}
                  <span>{isSaved ? "Keys Saved Successfully!" : "Save All API Keys"}</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: THEMES & STYLING */}
          {activeTab === "theme" && (
            <div className="space-y-4">
              <div className="text-xs font-mono text-zinc-300 font-semibold flex items-center gap-1.5">
                <Palette className="w-4 h-4 text-violet-400" /> Select Studio Canvas Theme:
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {THEME_PRESETS.map((theme) => {
                  const isSelected = currentThemeId === theme.id;
                  return (
                    <button
                      key={theme.id}
                      onClick={() => setThemeId(theme.id)}
                      className={`p-3.5 rounded-2xl border text-left flex items-center justify-between transition-all bg-gradient-to-br ${theme.previewClass} ${
                        isSelected
                          ? "border-cyan-400 shadow-[0_0_15px_rgba(0,229,255,0.2)] bg-zinc-900"
                          : "bg-zinc-950 border-white/[0.08] hover:border-white/[0.2]"
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="text-xs font-bold font-sans text-zinc-100 flex items-center gap-2">
                          <span
                            className="w-3 h-3 rounded-full border border-white/20 inline-block"
                            style={{ backgroundColor: theme.bgHex }}
                          />
                          {theme.name}
                        </div>
                        <div className="text-[10px] font-mono text-zinc-400">
                          Hex: {theme.bgHex} • Card: {theme.cardHex}
                        </div>
                      </div>
                      {isSelected && (
                        <div className="p-1 rounded-full bg-cyan-400 text-zinc-950">
                          <Check className="w-3.5 h-3.5" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
              <div className="p-3 rounded-xl bg-zinc-900 border border-white/[0.06] space-y-1">
                <p className="text-xs font-mono font-semibold text-zinc-200">Active Theme Status</p>
                <p className="text-[11px] font-mono text-zinc-400">
                  Theme settings update instantly across all studio panels, modals, and output cards.
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: HYPERPARAMETERS */}
          {activeTab === "model" && (
            <div className="space-y-5">
              {/* Temperature Slider */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-mono">
                  <span className="text-zinc-200 font-semibold flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Temperature:
                  </span>
                  <span className="text-amber-400 font-bold">{temperature}</span>
                </div>
                <input
                  type="range"
                  min="0.0"
                  max="1.5"
                  step="0.05"
                  value={temperature}
                  onChange={(e) => setTemperature(parseFloat(e.target.value))}
                  className="w-full accent-amber-400 h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] font-mono text-zinc-500">
                  <span>0.0 (Deterministic)</span>
                  <span>0.7 (Balanced)</span>
                  <span>1.5 (Creative)</span>
                </div>
              </div>

              {/* Top-P Slider */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-mono">
                  <span className="text-zinc-200 font-semibold flex items-center gap-1.5">
                    <Sliders className="w-3.5 h-3.5 text-cyan-400" /> Top-P (Nucleus Sampling):
                  </span>
                  <span className="text-cyan-400 font-bold">{topP}</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="1.0"
                  step="0.05"
                  value={topP}
                  onChange={(e) => setTopP(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
                />
              </div>

              {/* Max Tokens */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-mono">
                  <span className="text-zinc-200 font-semibold flex items-center gap-1.5">
                    <Cpu className="w-3.5 h-3.5 text-violet-400" /> Max Tokens Output:
                  </span>
                  <span className="text-violet-400 font-bold">{maxTokens} tk</span>
                </div>
                <input
                  type="range"
                  min="512"
                  max="8192"
                  step="256"
                  value={maxTokens}
                  onChange={(e) => setMaxTokens(parseInt(e.target.value))}
                  className="w-full accent-violet-400 h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
                />
              </div>

              {/* System Persona Presets */}
              <div className="space-y-2 pt-2 border-t border-white/[0.08]">
                <label className="text-xs font-mono text-zinc-200 font-semibold">
                  Default System Prompt Preset:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {SYSTEM_PRESETS.map((preset) => (
                    <button
                      key={preset.id}
                      onClick={() => {
                        setSelectedPresetId(preset.id);
                        setSystemPrompt(preset.systemPrompt);
                      }}
                      className={`p-2.5 rounded-xl border text-left text-xs font-mono transition-all ${
                        selectedPresetId === preset.id
                          ? "bg-amber-950/60 border-amber-500/60 text-amber-300 font-semibold"
                          : "bg-zinc-950 border-white/[0.08] text-zinc-400 hover:text-zinc-200"
                      }`}
                    >
                      <div className="text-zinc-100 font-sans font-bold">{preset.name}</div>
                      <div className="text-[10px] text-zinc-400 line-clamp-1">{preset.description}</div>
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={handleResetDefaults}
                className="w-full py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-white/[0.08] text-zinc-300 font-mono text-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5 text-zinc-400" />
                <span>Reset Hyperparameters to Defaults</span>
              </button>
            </div>
          )}

          {/* TAB 4: DATA & STORAGE */}
          {activeTab === "data" && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-zinc-950 border border-white/[0.08] space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-zinc-100 font-sans">Export Workspace Session</h4>
                    <p className="text-[11px] font-mono text-zinc-400">Download full session prompt history and model outputs in JSON format.</p>
                  </div>
                  <button
                    onClick={onExportSession}
                    className="px-3 py-1.5 rounded-xl bg-cyan-950 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-900 transition-colors text-xs font-mono flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" /> Export JSON
                  </button>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-zinc-950 border border-rose-900/40 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-rose-300 font-sans">Clear Workspace Arena</h4>
                    <p className="text-[11px] font-mono text-zinc-400">Clear all active outputs and text streams from the output arena.</p>
                  </div>
                  <button
                    onClick={onClearSession}
                    className="px-3 py-1.5 rounded-xl bg-rose-950 border border-rose-500/40 text-rose-300 hover:bg-rose-900 transition-colors text-xs font-mono flex items-center gap-1.5"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Clear Workspace
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-zinc-900/90 border-t border-white/[0.08] flex items-center justify-between shrink-0">
          <div className="text-[11px] font-mono text-zinc-500">
            Dark Flux Studio v2.5
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-100 font-mono text-xs font-bold transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
