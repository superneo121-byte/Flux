import React from "react";
import {
  Zap,
  Key,
  Trash2,
  Download,
  ShieldCheck,
  Cpu,
  HelpCircle,
  Settings,
} from "lucide-react";
import { BYOKSettings, SessionHistoryItem } from "../types";

interface NavbarProps {
  byok: BYOKSettings;
  onOpenBYOKModal: () => void;
  onOpenSettingsModal: () => void;
  onClearSession: () => void;
  selectedModelsCount: number;
  totalModelsCount: number;
  activeSessionHistory: SessionHistoryItem[];
  onExportSession: () => void;
  onShowShortcuts: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  byok,
  onOpenBYOKModal,
  onOpenSettingsModal,
  onClearSession,
  selectedModelsCount,
  totalModelsCount,
  activeSessionHistory,
  onExportSession,
  onShowShortcuts,
}) => {
  const hasUserKeys = Boolean(byok.openRouterApiKey || byok.groqApiKey || byok.geminiApiKey || byok.searchApiKey);

  return (
    <header className="sticky top-0 z-40 w-full bg-[#09090B]/80 backdrop-blur-md border-b border-white/[0.08] px-4 py-3">
      <div className="max-w-[1800px] mx-auto flex items-center justify-between">
        {/* Brand Logo & Name */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500/20 via-violet-500/20 to-zinc-900 border border-cyan-500/30 shadow-[0_0_15px_rgba(0,229,255,0.15)]">
            <Zap className="w-5 h-5 text-cyan-400 animate-pulse" />
            <div className="absolute inset-0 rounded-xl bg-cyan-400/10 blur-sm -z-10" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold tracking-wider text-base text-zinc-100 font-sans">
                DARK <span className="text-cyan-400 drop-shadow-[0_0_8px_rgba(0,229,255,0.4)]">FLUX</span> AI
              </span>
              <span className="px-1.5 py-0.5 text-[10px] font-mono font-semibold uppercase tracking-wider rounded border border-cyan-500/30 bg-cyan-950/40 text-cyan-300">
                Studio v2.5
              </span>
            </div>
            <p className="text-[11px] text-zinc-400 font-mono hidden sm:block">
              Multi-Model AI Orchestrator & Parallel Execution Arena
            </p>
          </div>
        </div>

        {/* Center Indicators */}
        <div className="hidden md:flex items-center gap-3 bg-zinc-900/80 border border-white/[0.08] px-3 py-1.5 rounded-lg text-xs font-mono">
          <div className="flex items-center gap-2 text-zinc-300">
            <Cpu className="w-3.5 h-3.5 text-violet-400" />
            <span>Active Arena:</span>
            <span className="text-cyan-400 font-semibold">{selectedModelsCount}</span>
            <span className="text-zinc-500">/ {totalModelsCount} Models</span>
          </div>
          <div className="h-3 w-[1px] bg-zinc-800" />
          <div className="flex items-center gap-1.5 text-zinc-400">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-emerald-400 font-medium">Server Gemini Live</span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Main Settings Button with Settings Icon */}
          <button
            onClick={onOpenSettingsModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-mono font-bold bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 shadow-[0_0_12px_rgba(0,229,255,0.15)] transition-all cursor-pointer"
            title="Open All Studio Settings: API Keys, Themes, Hyperparameters & Storage"
          >
            <Settings className="w-4 h-4 text-cyan-400 animate-spin-slow" />
            <span>Settings</span>
          </button>

          {/* BYOK Quick Button */}
          <button
            onClick={onOpenBYOKModal}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-mono font-medium border transition-all cursor-pointer ${
              hasUserKeys
                ? "bg-emerald-950/30 border-emerald-500/40 text-emerald-300 hover:bg-emerald-900/40 shadow-[0_0_10px_rgba(16,185,129,0.1)]"
                : "bg-zinc-900 border-white/[0.1] text-zinc-300 hover:bg-zinc-800 hover:border-zinc-700"
            }`}
            title="Manage BYOK API Keys"
          >
            <Key className={`w-3.5 h-3.5 ${hasUserKeys ? "text-emerald-400" : "text-zinc-400"}`} />
            <span className="hidden sm:inline">Keys</span>
            {hasUserKeys && <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />}
          </button>

          {/* Export Session */}
          <button
            onClick={onExportSession}
            disabled={activeSessionHistory.length === 0}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-mono bg-zinc-900 border border-white/[0.08] text-zinc-300 hover:bg-zinc-800 hover:text-zinc-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer"
            title="Export full session transcript to Markdown JSON"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden md:inline">Export</span>
          </button>

          {/* Shortcuts Info */}
          <button
            onClick={onShowShortcuts}
            className="p-1.5 rounded-xl bg-zinc-900 border border-white/[0.08] text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition-colors cursor-pointer"
            title="Keyboard Shortcuts Guide"
          >
            <HelpCircle className="w-4 h-4" />
          </button>

          {/* Clear Session */}
          <button
            onClick={onClearSession}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-mono bg-rose-950/20 border border-rose-900/30 text-rose-300 hover:bg-rose-900/30 transition-colors cursor-pointer"
            title="Clear active arena outputs"
          >
            <Trash2 className="w-3.5 h-3.5 text-rose-400" />
            <span className="hidden lg:inline">Clear Workspace</span>
          </button>
        </div>
      </div>
    </header>
  );
};
