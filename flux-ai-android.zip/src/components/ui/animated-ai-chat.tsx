"use client";

import { useEffect, useRef, useCallback, useTransition } from "react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import {
    Figma,
    MonitorIcon,
    Paperclip,
    SendIcon,
    XIcon,
    Sparkles,
    Command,
    Globe,
    Square,
    Wand2,
    Grid,
    Columns,
    Cpu
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import * as React from "react";
import { AVAILABLE_MODELS } from "@/constants/models";

interface UseAutoResizeTextareaProps {
    minHeight: number;
    maxHeight?: number;
}

function useAutoResizeTextarea({
    minHeight,
    maxHeight,
}: UseAutoResizeTextareaProps) {
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    const adjustHeight = useCallback(
        (reset?: boolean) => {
            const textarea = textareaRef.current;
            if (!textarea) return;

            if (reset) {
                textarea.style.height = `${minHeight}px`;
                return;
            }

            textarea.style.height = `${minHeight}px`;

            const newHeight = Math.max(
                minHeight,
                Math.min(
                    textarea.scrollHeight,
                    maxHeight ?? Number.POSITIVE_INFINITY
                )
            );

            textarea.style.height = `${newHeight}px`;
        },
        [minHeight, maxHeight]
    );

    useEffect(() => {
        const textarea = textareaRef.current;
        if (textarea) {
            textarea.style.height = `${minHeight}px`;
        }
    }, [minHeight]);

    useEffect(() => {
        const handleResize = () => adjustHeight();
        window.addEventListener("resize", handleResize);
        return () => window.removeEventListener("resize", handleResize);
    }, [adjustHeight]);

    return { textareaRef, adjustHeight };
}

interface CommandSuggestion {
    icon: React.ReactNode;
    label: string;
    description: string;
    prefix: string;
}

interface TextareaProps
  extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  containerClassName?: string;
  showRing?: boolean;
}

const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, containerClassName, showRing = true, ...props }, ref) => {
    const [isFocused, setIsFocused] = React.useState(false);
    
    return (
      <div className={cn("relative", containerClassName)}>
        <textarea
          className={cn(
            "flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm",
            "transition-all duration-200 ease-in-out",
            "placeholder:text-muted-foreground",
            "disabled:cursor-not-allowed disabled:opacity-50",
            showRing ? "focus-visible:outline-none focus-visible:ring-0 focus-visible:ring-offset-0" : "",
            className
          )}
          ref={ref}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          {...props}
        />
        
        {showRing && isFocused && (
          <motion.span 
            className="absolute inset-0 rounded-md pointer-events-none ring-2 ring-offset-0 ring-cyan-500/30"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          />
        )}
      </div>
    );
  }
);
Textarea.displayName = "Textarea";

export interface AnimatedAIChatProps {
    prompt?: string;
    setPrompt?: (p: string) => void;
    selectedModelIds?: string[];
    setSelectedModelIds?: (ids: string[]) => void;
    onRunFlux?: () => void;
    onStopFlux?: () => void;
    isRunning?: boolean;
    onEnhancePrompt?: () => void;
    isEnhancing?: boolean;
    viewMode?: "grid" | "diff";
    setViewMode?: (v: "grid" | "diff") => void;
    attachedImage?: string | null;
    setAttachedImage?: (img: string | null) => void;
    enableSearch?: boolean;
    setEnableSearch?: (e: boolean) => void;
    onOpenSettings?: () => void;
}

export function AnimatedAIChat({
    prompt = "",
    setPrompt,
    selectedModelIds = ["gemini-3.6-flash", "claude-3-5-sonnet", "deepseek-r1"],
    setSelectedModelIds,
    onRunFlux,
    onStopFlux,
    isRunning = false,
    onEnhancePrompt,
    isEnhancing = false,
    viewMode = "grid",
    setViewMode,
    attachedImage = null,
    setAttachedImage,
    enableSearch = false,
    setEnableSearch,
}: AnimatedAIChatProps) {
    const [localValue, setLocalValue] = useState(prompt);
    const [attachments, setAttachments] = useState<string[]>([]);
    const [, startTransition] = useTransition();
    const [activeSuggestion, setActiveSuggestion] = useState<number>(-1);
    const [showCommandPalette, setShowCommandPalette] = useState(false);
    const { textareaRef, adjustHeight } = useAutoResizeTextarea({
        minHeight: 60,
        maxHeight: 220,
    });
    const [, setInputFocused] = useState(false);
    const commandPaletteRef = useRef<HTMLDivElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    // Sync external prompt with localValue
    useEffect(() => {
        setLocalValue(prompt);
    }, [prompt]);

    const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        const val = e.target.value;
        setLocalValue(val);
        if (setPrompt) setPrompt(val);
        adjustHeight();
    };

    const commandSuggestions: CommandSuggestion[] = [
        { 
            icon: <Sparkles className="w-4 h-4 text-cyan-400" />, 
            label: "Refine Prompt", 
            description: "Auto-enhance with Gemini meta-prompter", 
            prefix: "/enhance" 
        },
        { 
            icon: <Globe className="w-4 h-4 text-emerald-400" />, 
            label: "Web Search", 
            description: "Enable live web search context grounding", 
            prefix: "/search" 
        },
        { 
            icon: <Figma className="w-4 h-4 text-violet-400" />, 
            label: "Design Specs", 
            description: "Generate UI component code and specifications", 
            prefix: "/design" 
        },
        { 
            icon: <MonitorIcon className="w-4 h-4 text-amber-400" />, 
            label: "Code Architecture", 
            description: "Design robust multi-module system schemas", 
            prefix: "/architect" 
        },
    ];

    useEffect(() => {
        if (localValue.startsWith('/') && !localValue.includes(' ')) {
            setShowCommandPalette(true);
            const matchingSuggestionIndex = commandSuggestions.findIndex(
                (cmd) => cmd.prefix.startsWith(localValue)
            );
            setActiveSuggestion(matchingSuggestionIndex >= 0 ? matchingSuggestionIndex : -1);
        } else {
            setShowCommandPalette(false);
        }
    }, [localValue]);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            const target = event.target as Node;
            const commandButton = document.querySelector('[data-command-button]');
            if (commandPaletteRef.current && 
                !commandPaletteRef.current.contains(target) && 
                !commandButton?.contains(target)) {
                setShowCommandPalette(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (showCommandPalette) {
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                setActiveSuggestion(prev => 
                    prev < commandSuggestions.length - 1 ? prev + 1 : 0
                );
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                setActiveSuggestion(prev => 
                    prev > 0 ? prev - 1 : commandSuggestions.length - 1
                );
            } else if (e.key === 'Tab' || e.key === 'Enter') {
                e.preventDefault();
                if (activeSuggestion >= 0) {
                    const selectedCommand = commandSuggestions[activeSuggestion];
                    executeCommand(selectedCommand.prefix);
                }
            } else if (e.key === 'Escape') {
                e.preventDefault();
                setShowCommandPalette(false);
            }
        } else if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
            e.preventDefault();
            if (isRunning) {
                if (onStopFlux) onStopFlux();
            } else if (localValue.trim()) {
                handleSendMessage();
            }
        }
    };

    const executeCommand = (prefix: string) => {
        if (prefix === '/enhance') {
            if (onEnhancePrompt) onEnhancePrompt();
        } else if (prefix === '/search') {
            if (setEnableSearch) setEnableSearch(!enableSearch);
            setLocalValue('');
            if (setPrompt) setPrompt('');
        } else {
            setLocalValue(prefix + ' ');
            if (setPrompt) setPrompt(prefix + ' ');
        }
        setShowCommandPalette(false);
    };

    const handleSendMessage = () => {
        if (localValue.trim() && !isRunning) {
            if (onRunFlux) onRunFlux();
        }
    };

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
            const resultStr = event.target?.result as string;
            if (setAttachedImage) setAttachedImage(resultStr);
            setAttachments(prev => [...prev, file.name]);
        };
        reader.readAsDataURL(file);
    };

    const removeAttachment = (index: number) => {
        setAttachments(prev => prev.filter((_, i) => i !== index));
        if (setAttachedImage) setAttachedImage(null);
    };

    const toggleModelSelection = (id: string) => {
        if (!setSelectedModelIds) return;
        if (selectedModelIds.includes(id)) {
            if (selectedModelIds.length > 1) {
                setSelectedModelIds(selectedModelIds.filter((m) => m !== id));
            }
        } else {
            setSelectedModelIds([...selectedModelIds, id]);
        }
    };

    return (
        <div className="w-full relative py-2">
            {/* Model Selector Pills & Mode Bar */}
            <div className="mb-3 flex flex-wrap items-center justify-between gap-3 px-1">
                <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-xs font-mono text-zinc-400 font-semibold flex items-center gap-1">
                        <Cpu className="w-3.5 h-3.5 text-cyan-400" /> Target Models ({selectedModelIds.length}):
                    </span>
                    {AVAILABLE_MODELS.slice(0, 6).map((model) => {
                        const isSelected = selectedModelIds.includes(model.id);
                        return (
                            <button
                                key={model.id}
                                type="button"
                                onClick={() => toggleModelSelection(model.id)}
                                className={`px-2.5 py-1 rounded-lg text-[11px] font-mono transition-all border flex items-center gap-1.5 cursor-pointer ${
                                    isSelected
                                        ? `bg-zinc-900 ${model.tagColor} font-semibold shadow-sm`
                                        : "bg-zinc-950/60 border-white/[0.06] text-zinc-400 hover:text-zinc-200"
                                }`}
                            >
                                <span className={`w-1.5 h-1.5 rounded-full ${isSelected ? "bg-cyan-400" : "bg-zinc-600"}`} />
                                {model.name}
                            </button>
                        );
                    })}
                </div>

                {/* View Mode Switcher */}
                <div className="flex items-center bg-zinc-900 border border-white/[0.08] p-0.5 rounded-lg text-xs font-mono">
                    <button
                        type="button"
                        onClick={() => setViewMode && setViewMode("grid")}
                        className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                            viewMode === "grid" ? "bg-zinc-800 text-cyan-400 font-bold" : "text-zinc-400 hover:text-zinc-200"
                        }`}
                    >
                        <Grid className="w-3.5 h-3.5" />
                        <span>Grid</span>
                    </button>
                    <button
                        type="button"
                        onClick={() => setViewMode && setViewMode("diff")}
                        className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                            viewMode === "diff" ? "bg-zinc-800 text-violet-400 font-bold" : "text-zinc-400 hover:text-zinc-200"
                        }`}
                    >
                        <Columns className="w-3.5 h-3.5" />
                        <span>Diff View</span>
                    </button>
                </div>
            </div>

            {/* Main Interactive Animated Chat Box */}
            <motion.div 
                className="relative backdrop-blur-2xl bg-[#121215] rounded-2xl border border-white/[0.1] shadow-2xl focus-within:border-cyan-500/50 transition-all overflow-hidden"
                initial={{ scale: 0.99 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.2 }}
            >
                <AnimatePresence>
                    {showCommandPalette && (
                        <motion.div 
                            ref={commandPaletteRef}
                            className="absolute left-4 right-4 bottom-full mb-2 backdrop-blur-xl bg-zinc-950/95 rounded-xl z-50 shadow-2xl border border-white/10 overflow-hidden"
                            initial={{ opacity: 0, y: 5 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: 5 }}
                            transition={{ duration: 0.15 }}
                        >
                            <div className="py-1 bg-zinc-950">
                                {commandSuggestions.map((suggestion, index) => (
                                    <motion.div
                                        key={suggestion.prefix}
                                        className={cn(
                                            "flex items-center justify-between px-3.5 py-2.5 text-xs transition-colors cursor-pointer border-b border-white/[0.04] last:border-none",
                                            activeSuggestion === index 
                                                ? "bg-zinc-900 text-zinc-100" 
                                                : "text-zinc-400 hover:bg-zinc-900/60"
                                        )}
                                        onClick={() => executeCommand(suggestion.prefix)}
                                    >
                                        <div className="flex items-center gap-2.5">
                                            <div className="w-5 h-5 flex items-center justify-center">
                                                {suggestion.icon}
                                            </div>
                                            <div>
                                                <div className="font-semibold text-zinc-100 font-sans">{suggestion.label}</div>
                                                <div className="text-[11px] text-zinc-400 font-mono">{suggestion.description}</div>
                                            </div>
                                        </div>
                                        <kbd className="px-2 py-0.5 rounded bg-zinc-800 text-[10px] font-mono text-cyan-300 border border-white/[0.08]">
                                            {suggestion.prefix}
                                        </kbd>
                                    </motion.div>
                                ))}
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>

                {/* Input Textarea Area */}
                <div className="p-4">
                    <Textarea
                        ref={textareaRef}
                        value={localValue}
                        onChange={handleTextChange}
                        onKeyDown={handleKeyDown}
                        onFocus={() => setInputFocused(true)}
                        onBlur={() => setInputFocused(false)}
                        placeholder="Enter your prompt to execute simultaneously across selected AI models... (⌘ + Enter)"
                        containerClassName="w-full"
                        className={cn(
                            "w-full px-1 py-1",
                            "resize-none",
                            "bg-transparent",
                            "border-none",
                            "text-zinc-100 text-sm font-sans placeholder:text-zinc-500",
                            "focus:outline-none",
                            "min-h-[60px]"
                        )}
                        style={{ overflow: "hidden" }}
                        showRing={false}
                    />
                </div>

                {/* Image & File Attachment Thumbnails */}
                <AnimatePresence>
                    {(attachedImage || attachments.length > 0) && (
                        <motion.div 
                            className="px-4 pb-3 flex gap-2 flex-wrap items-center"
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: "auto" }}
                            exit={{ opacity: 0, height: 0 }}
                        >
                            {attachedImage && (
                                <div className="relative group rounded-xl overflow-hidden border border-cyan-500/40 bg-zinc-900 p-1">
                                    <img src={attachedImage} alt="Attachment" className="w-12 h-12 object-cover rounded-lg" />
                                    <button
                                        type="button"
                                        onClick={() => removeAttachment(0)}
                                        className="absolute top-1 right-1 p-0.5 rounded-full bg-black/80 text-white hover:bg-rose-600 transition-colors cursor-pointer"
                                    >
                                        <XIcon className="w-3 h-3" />
                                    </button>
                                </div>
                            )}
                            {attachments.map((file, index) => (
                                <motion.div
                                    key={index}
                                    className="flex items-center gap-2 text-xs bg-zinc-900 border border-white/[0.08] py-1.5 px-3 rounded-lg text-zinc-300 font-mono"
                                    initial={{ opacity: 0, scale: 0.9 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    exit={{ opacity: 0, scale: 0.9 }}
                                >
                                    <span>{file}</span>
                                    <button 
                                        type="button"
                                        onClick={() => removeAttachment(index)}
                                        className="text-zinc-400 hover:text-white transition-colors cursor-pointer"
                                    >
                                        <XIcon className="w-3 h-3" />
                                    </button>
                                </motion.div>
                            ))}
                        </motion.div>
                    )}
                </AnimatePresence>

                {/* Bottom Control Bar */}
                <div className="p-3 bg-zinc-950/80 border-t border-white/[0.06] flex flex-wrap items-center justify-between gap-3">
                    <div className="flex flex-wrap items-center gap-2">
                        {/* Attachment Button */}
                        <input
                            ref={fileInputRef}
                            type="file"
                            accept="image/*"
                            onChange={handleImageUpload}
                            className="hidden"
                        />
                        <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            className="p-2 text-zinc-400 hover:text-zinc-100 bg-zinc-900 hover:bg-zinc-800 border border-white/[0.06] rounded-xl transition-all cursor-pointer"
                            title="Attach image or screenshot for multimodal vision models"
                        >
                            <Paperclip className="w-4 h-4 text-cyan-400" />
                        </button>

                        {/* Slash Command Palette Trigger */}
                        <button
                            type="button"
                            data-command-button
                            onClick={(e) => {
                                e.stopPropagation();
                                setShowCommandPalette(prev => !prev);
                            }}
                            className={cn(
                                "flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-mono rounded-xl border transition-all cursor-pointer",
                                showCommandPalette 
                                    ? "bg-cyan-950 border-cyan-500/50 text-cyan-300" 
                                    : "bg-zinc-900 border-white/[0.06] text-zinc-400 hover:text-zinc-200"
                            )}
                        >
                            <Command className="w-3.5 h-3.5 text-violet-400" />
                            <span className="hidden sm:inline">Commands</span>
                        </button>

                        {/* AI Prompt Auto-Enhancer Button */}
                        <button
                            type="button"
                            onClick={onEnhancePrompt}
                            disabled={isEnhancing || !localValue.trim()}
                            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-zinc-900 border border-white/[0.06] text-zinc-300 hover:text-cyan-300 hover:bg-zinc-800 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-mono transition-colors cursor-pointer"
                            title="Auto-enhance prompt clarity using Gemini"
                        >
                            <Wand2 className={`w-3.5 h-3.5 ${isEnhancing ? "text-cyan-400 animate-spin" : "text-amber-400"}`} />
                            <span className="hidden sm:inline">{isEnhancing ? "Enhancing..." : "Enhance"}</span>
                        </button>

                        {/* Live Web Grounding Search Toggle */}
                        <button
                            type="button"
                            onClick={() => setEnableSearch && setEnableSearch(!enableSearch)}
                            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border font-mono text-xs transition-all cursor-pointer ${
                                enableSearch
                                    ? "bg-emerald-950/80 border-emerald-500/60 text-emerald-300 shadow-[0_0_15px_rgba(16,185,129,0.25)]"
                                    : "bg-zinc-900 border-white/[0.06] text-zinc-400 hover:text-zinc-200"
                            }`}
                            title="Toggle real-time web search grounding across all models"
                        >
                            <Globe className={`w-3.5 h-3.5 ${enableSearch ? "text-emerald-400 animate-pulse" : "text-zinc-500"}`} />
                            <span className="font-semibold">Live Web Search</span>
                            <span className={`w-2 h-2 rounded-full ${enableSearch ? "bg-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.8)]" : "bg-zinc-600"}`} />
                        </button>
                    </div>

                    {/* Execution Trigger (Run / Halt) */}
                    <div className="flex items-center gap-2">
                        {isRunning ? (
                            <button
                                type="button"
                                onClick={onStopFlux}
                                className="px-4 py-2 rounded-xl text-xs font-mono font-bold bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-950/50 flex items-center gap-2 transition-all cursor-pointer"
                            >
                                <Square className="w-3.5 h-3.5 fill-current" />
                                <span>Halt Generation</span>
                            </button>
                        ) : (
                            <motion.button
                                type="button"
                                onClick={handleSendMessage}
                                whileHover={{ scale: 1.02 }}
                                whileTap={{ scale: 0.98 }}
                                disabled={!localValue.trim()}
                                className={cn(
                                    "px-5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-2 shadow-lg cursor-pointer",
                                    localValue.trim()
                                        ? "bg-cyan-500 hover:bg-cyan-400 text-zinc-950 shadow-cyan-500/20"
                                        : "bg-zinc-800 text-zinc-500 cursor-not-allowed"
                                )}
                            >
                                <SendIcon className="w-3.5 h-3.5" />
                                <span>Run Flux</span>
                            </motion.button>
                        )}
                    </div>
                </div>
            </motion.div>
        </div>
    );
}
