import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Columns, ArrowLeftRight } from "lucide-react";
import { ModelRunResult } from "../types";
import { AVAILABLE_MODELS } from "../constants/models";

interface DiffViewerModalProps {
  results: Record<string, ModelRunResult>;
  selectedModelIds: string[];
}

export const DiffViewerModal: React.FC<DiffViewerModalProps> = ({
  results,
  selectedModelIds,
}) => {
  const [modelA, setModelA] = useState<string>(selectedModelIds[0] || "gemini-3.6-flash");
  const [modelB, setModelB] = useState<string>(selectedModelIds[1] || selectedModelIds[0] || "claude-3-5-sonnet");

  const resultA = results[modelA];
  const resultB = results[modelB];

  const specA = AVAILABLE_MODELS.find((m) => m.id === modelA);
  const specB = AVAILABLE_MODELS.find((m) => m.id === modelB);

  return (
    <div className="p-4 space-y-4">
      {/* Selector Header Bar */}
      <div className="p-4 rounded-2xl bg-[#18181B] border border-white/[0.08] flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Columns className="w-5 h-5 text-violet-400" />
          <h3 className="text-sm font-bold font-sans text-zinc-100">
            Side-by-Side Arena Output Diff
          </h3>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Model A Selector */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-cyan-400 font-semibold">Model A:</span>
            <select
              value={modelA}
              onChange={(e) => setModelA(e.target.value)}
              className="bg-zinc-950 border border-white/[0.08] rounded-xl px-3 py-1.5 text-xs font-mono text-zinc-100 focus:outline-none focus:border-cyan-500/50"
            >
              {selectedModelIds.map((id) => (
                <option key={id} value={id}>
                  {AVAILABLE_MODELS.find((m) => m.id === id)?.name || id}
                </option>
              ))}
            </select>
          </div>

          <ArrowLeftRight className="w-4 h-4 text-zinc-500 hidden sm:block" />

          {/* Model B Selector */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-violet-400 font-semibold">Model B:</span>
            <select
              value={modelB}
              onChange={(e) => setModelB(e.target.value)}
              className="bg-zinc-950 border border-white/[0.08] rounded-xl px-3 py-1.5 text-xs font-mono text-zinc-100 focus:outline-none focus:border-violet-500/50"
            >
              {selectedModelIds.map((id) => (
                <option key={id} value={id}>
                  {AVAILABLE_MODELS.find((m) => m.id === id)?.name || id}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Side by Side Dual Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Panel A */}
        <div className="rounded-2xl bg-[#18181B] border border-cyan-500/30 overflow-hidden flex flex-col">
          <div className="p-3 bg-zinc-900 border-b border-white/[0.08] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold font-sans text-cyan-300">{specA?.name || modelA}</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-950/60 text-cyan-400 border border-cyan-500/30">
                {specA?.provider}
              </span>
            </div>
            <div className="text-[10px] font-mono text-zinc-400">
              Latency: {resultA?.latencyMs ? `${resultA.latencyMs}ms` : specA?.estLatencyMs ? `~${specA.estLatencyMs}ms` : "—"}
            </div>
          </div>
          <div className="p-4 flex-1 max-h-[60dvh] lg:max-h-[600px] overflow-y-auto custom-scrollbar font-sans text-xs text-zinc-200 leading-relaxed">
            {resultA?.text ? (
              <ReactMarkdown remarkPlugins={[remarkGfm]}>{resultA.text}</ReactMarkdown>
            ) : (
              <div className="text-zinc-500 font-mono text-center py-12">No response data for Model A yet.</div>
            )}
          </div>
        </div>

        {/* Panel B */}
        <div className="rounded-2xl bg-[#18181B] border border-violet-500/30 overflow-hidden flex flex-col">
          <div className="p-3 bg-zinc-900 border-b border-white/[0.08] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold font-sans text-violet-300">{specB?.name || modelB}</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-violet-950/60 text-violet-400 border border-violet-500/30">
                {specB?.provider}
              </span>
            </div>
            <div className="text-[10px] font-mono text-zinc-400">
              Latency: {resultB?.latencyMs ? `${resultB.latencyMs}ms` : specB?.estLatencyMs ? `~${specB.estLatencyMs}ms` : "—"}
            </div>
          </div>
          <div className="p-4 flex-1 max-h-[60dvh] lg:max-h-[600px] overflow-y-auto custom-scrollbar font-sans text-xs text-zinc-200 leading-relaxed">
            {resultB?.text ? (
              <ReactMarkdown remarkPlugins={[remarkGfm]}>{resultB.text}</ReactMarkdown>
            ) : (
              <div className="text-zinc-500 font-mono text-center py-12">No response data for Model B yet.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
