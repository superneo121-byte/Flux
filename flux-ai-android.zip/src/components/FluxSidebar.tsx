import React from "react";
import { Plus, MessageSquare, Trash2, Settings } from "lucide-react";
import { SessionHistoryItem } from "../types";

interface FluxSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onNewChat: () => void;
  history: SessionHistoryItem[];
  onLoadHistoryItem: (item: SessionHistoryItem) => void;
  onDeleteHistoryItem: (id: string, e: React.MouseEvent) => void;
  onOpenSettings: () => void;
}

const isPhone = () => typeof window !== "undefined" && window.innerWidth < 768;

export const FluxSidebar: React.FC<FluxSidebarProps> = ({
  isOpen,
  onClose,
  onNewChat,
  history,
  onLoadHistoryItem,
  onDeleteHistoryItem,
  onOpenSettings,
}) => {
  if (!isOpen) return null;

  // On phones the sidebar is a drawer: close it after any choice.
  const closeIfPhone = () => {
    if (isPhone()) onClose();
  };

  return (
    <>
      {/* Backdrop (phones only) */}
      <div className="md:hidden fixed inset-0 z-40 bg-black/60 animate-fade-in" onClick={onClose} />

      <aside className="fixed md:static inset-y-0 left-0 z-40 w-[85vw] max-w-80 md:w-80 md:max-w-none bg-slate-50 dark:bg-[#121318] border-r border-zinc-200 dark:border-white/[0.08] flex flex-col pt-[calc(3.5rem+env(safe-area-inset-top))] md:pt-0 pb-[env(safe-area-inset-bottom)] md:pb-0 h-full shadow-2xl md:shadow-none">
        <div className="p-4 flex flex-col gap-3 flex-1 min-h-0 overflow-y-auto custom-scrollbar overscroll-contain">
          <button
            onClick={() => {
              onNewChat();
              closeIfPhone();
            }}
            className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-sans font-semibold py-3 md:py-2.5 px-4 rounded-xl shadow-md shadow-indigo-600/20 transition-all text-sm cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>New Chat</span>
          </button>

          <div className="pt-2 flex items-center justify-between text-xs font-mono font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 px-2">
            <span>History</span>
            <span className="text-[10px] bg-zinc-200 dark:bg-zinc-800 px-2 py-0.5 rounded-full text-zinc-700 dark:text-zinc-300">
              {history.length}
            </span>
          </div>

          <div className="flex flex-col gap-1.5 flex-1">
            {history.length === 0 ? (
              <div className="p-4 rounded-xl border border-dashed border-zinc-300 dark:border-white/[0.08] text-center text-xs font-mono text-zinc-400 dark:text-zinc-500 my-4">
                No recent conversations yet.
              </div>
            ) : (
              history.map((item) => (
                <div
                  key={item.id}
                  onClick={() => {
                    onLoadHistoryItem(item);
                    closeIfPhone();
                  }}
                  className="group flex items-center justify-between pl-3 pr-1 py-1.5 min-h-12 md:min-h-0 rounded-xl bg-white dark:bg-zinc-900/60 hover:bg-zinc-100 dark:hover:bg-zinc-800/80 active:bg-zinc-100 dark:active:bg-zinc-800 border border-zinc-200 dark:border-white/[0.04] text-zinc-800 dark:text-zinc-300 transition-all cursor-pointer shadow-xs"
                >
                  <div className="flex items-center gap-2.5 min-w-0 pr-2">
                    <MessageSquare className="w-4 h-4 text-indigo-500 dark:text-indigo-400 shrink-0" />
                    <span className="text-sm md:text-xs font-medium truncate font-sans">{item.prompt}</span>
                  </div>
                  {/* Always visible on touch screens (no hover there) */}
                  <button
                    onClick={(e) => onDeleteHistoryItem(item.id, e)}
                    className="md:opacity-0 md:group-hover:opacity-100 p-2.5 md:p-1.5 rounded-lg text-zinc-400 hover:text-rose-500 dark:hover:text-rose-400 active:text-rose-500 hover:bg-zinc-200 dark:hover:bg-zinc-800 transition-all shrink-0"
                    title="Delete chat from history"
                    aria-label="Delete chat"
                  >
                    <Trash2 className="w-4 h-4 md:w-3.5 md:h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>

          <div className="pt-3 border-t border-zinc-200 dark:border-white/[0.08] text-xs font-mono">
            <button
              onClick={() => {
                onOpenSettings();
                closeIfPhone();
              }}
              className="flex items-center gap-2 px-3 py-3 md:py-2 rounded-xl bg-white dark:bg-zinc-900/80 hover:bg-zinc-100 dark:hover:bg-zinc-800 border border-zinc-200 dark:border-white/[0.06] text-zinc-700 dark:text-zinc-300 w-full transition-colors cursor-pointer shadow-xs"
            >
              <Settings className="w-4 h-4 text-indigo-500 dark:text-indigo-400" />
              <span>Settings & Preferences</span>
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
