# Flux AI (Android)

Multi-model AI studio, packaged as an Android app with Capacitor. All API calls run on the device (see `src/lib/apiClient.ts`); add your keys in **BYOK Settings** inside the app.

## Build the APK with GitHub Actions
1. Push this repo to GitHub (branch `main`).
2. Open **Actions → Build Android APK** (runs on every push, or click *Run workflow*).
3. Download the `flux-ai-debug-apk` artifact and install `app-debug.apk`.

## Run locally
```
npm install
npm run dev            # web preview
npm run build && npx cap add android && npx cap sync android
npx cap open android   # Android Studio
```
